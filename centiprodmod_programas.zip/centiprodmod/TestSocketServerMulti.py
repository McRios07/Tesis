#import RPi.GPIO as GPIO
import threading
import socket
import re
from TestSemaforos import Torretas
import os
import time
import subprocess
from TestNegocioCentiProd import Negocio
import datetime

class IndicadorRed:

    torretas = None

    negocio = None

    ipBascula = '192.168.254.112'  # The server's hostname or IP address
    puertoBascula = 2101        # The port used by the server

    #producto = "SIN PRODUCTO"
    spLow = 0.0
    spUnder = 0.0
    spOver = 0.0
    spHigh = 0.0
    spTara = 0.0
    Indicador = None
    hBascula = None
    deboMostrarNivelEnTorreta = False
    numeroTorreta = 1
    grupo = 0
    numeroCentiprod = 0

    #-- Variables de peso
    pesoActual = "" # peso que actualmente tiene el indicador
    pesoThreshold = 0.0 # nivel de peso que se debe rebasar para asumir que hay peso sobre la bascula
    listaPesos = [] # Lista que almacena los pesos que se van recibiendo del indicador
    subioDeCero = False # Si el peso ha subido de cero.
    pesoModa = 0.0 # Peso que se repitio mas en la lista de pesos
    producto = "" #Nombre del producto que actualmente procesa la bascula
    descripcionProducto = "" #Descripcion del producto que actualmente procesa a bascula
    nivelPesoActual = "LOW"
    nivelPesoEnModa = "LOW"
    servidorIntermediario = None

    #-- Whatchdog
    wdEstadoConexion = None
    contadorVerificarConexion = 0
    estoyConectado = False

    def CargarSetpoints(self,num):
        setpoints = self.negocio.ObtenerSetPoints(num).split(",")
        print(setpoints)
        self.spLow = float(setpoints[0])
        self.spUnder = float(setpoints[1])
        self.spOver = float(setpoints[2])
        self.spHigh = float(setpoints[3])
        self.spTara = float(setpoints[4])
        self.producto = setpoints[5]

    def __init__(self, ip, puerto, mostrarNivel, num, instanciaServidorLocal):
        self.ipBascula = ip
        self.puertoBascula = puerto
        self.deboMostrarNivelEnTorreta = mostrarNivel
        self.numeroTorreta = num
        self.torretas =  Torretas(num)
        self.servidorIntermediario = instanciaServidorLocal
        self.negocio = Negocio()
        self.grupo = self.negocio.ObtenerIdGrupoBascula(num)
        self.numeroCentiprod = self.negocio.ObtenerNumBascula(num)
        self.CargarSetpoints(num)
        self.WatchdogVerificadorConexion()

    def PesoEstabilizado(self):
        self.EnviarPesoEstable(self)

    #-----------------------------------------------------------------------------------------------

    def EncontrarModa(self,lst):
        #print("buscando moda")
        resp = max(set(lst), key = lst.count)
        #print ("modadef: " + str(resp))
        return resp

    def ProcesarPeso(self, peso):
        #print("Peso: " + str(peso))
        if peso > self.pesoThreshold and self.subioDeCero == False:
            self.subioDeCero = True
            print("[-] Subio de cero.")

        if peso > self.pesoThreshold:
            self.listaPesos.append(peso)
            #print("Agregue: " + str(peso))

        if len(self.listaPesos) > 1000:
            #print("borre: " + str(self.listaPesos[0]))
            del self.listaPesos[0]

        #print("peso: " + str(peso) + " subioDeCero: " + str(self.subioDeCero))
        if peso <= 0 and self.subioDeCero == True:
            #print("Calculando moda")
            tmpModa = self.EncontrarModa(self.listaPesos)
            #print("Moda: " + str(tmpModa))
            del self.listaPesos[:]
            self.subioDeCero = False
            #time.sleep(0.2)
            #print ("Envie moda")
            self.nivelPesoEnModa = self.nivelPesoActual
            print("[-] Peso: ", tmpModa)
            #self.servidorIntermediario.sendall(str.encode("Peso [" + str(self.ipBascula) + "]: " + str(tmpModa)))
            ts = time.time()
            hora = str(datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S'))
            fecha = str(datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d'))
            cadenaEnviar = str.encode("#" + str(self.grupo) +"#" + str(self.numeroCentiprod) + "#0001#" +  str(tmpModa * 1000) + "#g#" + hora + "#" + fecha + "#" + self.nivelPesoEnModa +"##" + str(self.spTara))
            self.servidorIntermediario.sendall(cadenaEnviar)
            print("Bascula " + str(self.numeroTorreta) + ", envio Peso. ")

    def getNumbers(self, strg):
        array = re.findall(r'[0-9\-.]+', strg)
        return array

    def MostrarNivelEnTorreta(self, peso):
        #print("G:", peso)
        if(peso <= self.spUnder):
            self.torretas.EncenderLuzSemaforo("amarillo")
            #print("amarillo")
        elif(peso > self.spUnder and peso < self.spOver):
            self.torretas.EncenderLuzSemaforo("verde")
            #print("verde")
        elif(peso >= self.spOver):
            self.torretas.EncenderLuzSemaforo("rojo")
            #print("rojo")

    def ManejardorBascula(self):
        self.Indicador = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.Indicador.connect((self.ipBascula, self.puertoBascula))
        self.Indicador.setblocking(0)

        while True:
            try:
                data = str(self.Indicador.recv(512))
                #print (data)
                peso = ''.join(self.getNumbers(data.replace("x02", "")))
                #if self.ipBascula == "192.168.254.112":
                    #print("P: " + str(peso))
                if self.deboMostrarNivelEnTorreta == True:
                    try:
                        #print("Muestro en torreta: " + str(peso.strip()))
                        self.MostrarNivelEnTorreta(float(peso.strip()) * 1000)
                    except:
                        pass
                try:
                    self.ProcesarPeso(float(peso.strip()))
                except:
                    pass
            except socket.error:
                #print("error: ", e)
                ''' No hay respuesta '''
            #time.sleep(0.3)

    def WatchdogVerificadorConexion(self):
        self.hWachdog = threading.Thread(target=self.VerificarConexion)
        self.hWachdog.start()

    def IniciarManejadorBascula(self):
        self.hBascula = threading.Thread(target=self.ManejardorBascula)
        self.hBascula.start()

    def VerificarConexion(self):
        print("[-] Watchdog Iniciado.")
        while True:
            if self.contadorVerificarConexion == 10:
                #response = subprocess.run(["ping", "-c", "1", self.ipBascula]).returncode
                response = os.system("ping -c 1 -w2 " + self.ipBascula + " > /dev/null 2>&1")

                if response == 0:
                    self.estoyConectado = True
                    #print("[-] ",self.ipBascula, " sigue conectado.")
                else:
                    #print("[-] ",self.ipBascula, " esta desconectado.")
                    self.estoyConectado = False
                    try:
                        #-- si de desconecto intento recuperar la conexion
                        print("Conexion perdida con ", self.ipBascula, ", recuperando...")
                        self.hBascula.do_run = False
                        self.hBascula.join()
                        self.Indicador.close()
                        self.IniciarManejadorBascula
                    except socket.error as e:
                        print("[-] Al cerrar socket desconectado: ", e)

                self.contadorVerificarConexion = 0
            else:
                self.contadorVerificarConexion = self.contadorVerificarConexion + 1

            time.sleep(1)



''' Testing '''

'''
GPIO.cleanup()

# self, ip, puerto, low, under, over, high, tara, mostrarNivel, num
Indicador1 = IndicadorRed("192.168.254.112", 2101, 1, 2, 4, 5, 0, True, 1)
Indicador1.IniciarManejadorBascula()

Indicador2 = IndicadorRed("192.168.254.110", 2101, 1, 2, 4, 5, 0, True, 2)
Indicador2.IniciarManejadorBascula()


print("Inicializado")

'''