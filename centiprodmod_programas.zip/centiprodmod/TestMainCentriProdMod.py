import RPi.GPIO as GPIO
from MainServerSocketTest import ServidorPrincipal
import threading
import subprocess
import time


''' Testing '''

servidor = None
mainServer = None

def ConectarIndicador1():
    print("[-] Conectando Bascula 1")
    subprocess.call(["python", "/home/pi/Desktop/python/TestBascula1.py"])

def ConectarIndicador2():
    print("[-] Conectando Bascula 2")
    subprocess.call(["python", "/home/pi/Desktop/python/TestBascula2.py"])

def ManejadorServidorPrincipal():
    print("[-] Inicializando servidor principal...")
    servidor = ServidorPrincipal()
    servidor.IniciarEscucha()

#-- Inicio el Hilo de escucha del servidor principal
hServidorPrincipal = threading.Thread(target=ManejadorServidorPrincipal)
hServidorPrincipal.start()


GPIO.cleanup()
print("[-] Iniciando el servidor...")
time.sleep(5)
print("[-] servidor en linea...")


#-- Inicio el Hilo de  conexion del indicador 1
#hIndicador1 = threading.Thread(target=ConectarIndicador1)
#hIndicador1.start()


''' '''
#-- Inicio el Hilo de  conexion del indicador 2
#hIndicador2 = threading.Thread(target=ConectarIndicador2)
#hIndicador2.start()


''' Testing '''

'''
def ManejadorConexionConServidorPrincipal():
    print("[-] Conectando al servidor principal...")
    time.sleep(5)
    mainServer = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    mainServer.connect(('localhost', 33000))
    mainServer.setblocking(0)

#-- Inicio el Hilo de conexion con el servidor principal
hConexionServidorPrincipal = threading.Thread(target=ManejadorConexionConServidorPrincipal)
hConexionServidorPrincipal.start()


# self, ip, puerto, low, under, over, high, tara, mostrarNivel, num
Indicador1 = IndicadorRed("192.168.254.112", 2101, True, 1, mainServer)
Indicador1.IniciarManejadorBascula()


Indicador2 = IndicadorRed("192.168.254.110", 2101, True, 2, mainServer)
Indicador2.IniciarManejadorBascula()
'''

print("[-] Se ha enviado a ejecutar toda la Inicializacion.")




