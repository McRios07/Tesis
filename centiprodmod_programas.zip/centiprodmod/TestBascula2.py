import time
import socket
import threading
from TestSocketServerMulti import IndicadorRed
from TestNegocioCentiProd import Negocio

mainServer = None
negocio = None

def ManejadorConexionConServidorPrincipal():
    print("[-] Conectando al servidor principal...")
    mainServer = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    mainServer.connect(('localhost', 33000))
    mainServer.setblocking(0)
    time.sleep(2)

    negocio = Negocio()
    ip = str(negocio.ObtenerIpBascula(2))
    puerto = int(negocio. ObtenerPuertoBascula(2))
    # self, ip, puerto, mostrarNivel, num
    Indicador = IndicadorRed(ip, puerto, True, 2, mainServer)
    Indicador.IniciarManejadorBascula()

#-- Inicio el Hilo de conexion con el servidor principal
hConexionServidorPrincipal = threading.Thread(target=ManejadorConexionConServidorPrincipal)
hConexionServidorPrincipal.start()
