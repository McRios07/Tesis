import RPi.GPIO as GPIO
from RPLCD.gpio import CharLCD

class DisplayLCD:

    # Define GPIO to LCD mapping
    '''
    LCD_RS = 2
    LCD_E  = 3
    LCD_D4 = 4
    LCD_D5 = 17
    LCD_D6 = 27
    LCD_D7 = 22
    LED_ON = 22
    '''
    LCD_RS = 28
    LCD_E  = 29
    LCD_D4 = 30
    LCD_D5 = 31
    LCD_D6 = 32
    LCD_D7 = 33
    LED_ON = 33
    
    disp = None

    def __init__(self):
        pass

    def InicializarDisplay(self):
        self.disp = CharLCD(pin_rs=self.LCD_RS, pin_rw=self.LED_ON, pin_e=self.LCD_E,
                      pins_data=[self.LCD_D4, self.LCD_D5, self.LCD_D6, self.LCD_D7],
                      numbering_mode=GPIO.BCM,
                      cols=20, rows=4, dotsize=8,
                      charmap='A02', compat_mode=True,
                      auto_linebreaks=True)

    def BorrarPantalla(self):
        self.disp.clear()

    def Escribir(self, texto, linea = 0, posicion = 0):
        self.disp.cursor_pos = (linea, posicion)
        self.disp.write_string(texto)


''' Testing '''

'''
lcd = DisplayLCD()
lcd.InicializarDisplay()
lcd.BorrarPantalla()
lcd.Escribir("Hola mundirijillo", 1, 0)
'''




