import RPi.GPIO as GPIO
import TestSocketServerMulti as Indicador

class MainProgram:

    def __init__(self):
        GPIO.cleanup()

    def PesoRecibido1(sender, earg):
        print("Peso estable bascula: ", sender.numeroTorreta, ":", sender.pesoModa)

    def PesoRecibido2(sender, earg):
        print("Peso estable bascula: ", sender.numeroTorreta, ":", sender.pesoModa)

    def Iniciar(self):
        # self, ip, puerto, low, under, over, high, tara, mostrarNivel, num
        Indicador1 = Indicador.IndicadorRed("192.168.254.112", 2101, 1, 2, 4, 5, 0, True, 1)
        Indicador1.EnviarPesoEstable += self.PesoRecibido1
        Indicador1.IniciarManejadorBascula()

        Indicador2 = Indicador.IndicadorRed("192.168.254.110", 2101, 1, 2, 4, 5, 0, True, 2)
        Indicador2.EnviarPesoEstable += self.PesoRecibido2
        Indicador2.IniciarManejadorBascula()

        print("Inicializado")

principal = MainProgram()

principal.Iniciar()