from pad4pi import rpi_gpio
import time
from TestLCD_T1 import DisplayLCD

class Teclado:

    KEYPAD = [
            ["7","8","9","F"],
            ["4","5","6","E"],
            ["1","2","3","D"],
            ["A","0","B","C"]
    ]

    #ROW_PINS = [5,11,9,10] # BCM
    #COL_PINS = [6,13,19,26] # BCM
    COL_PINS = [3,2,1,0] # BCM
    ROW_PINS = [4,5,6,7] # BCM

    factory = rpi_gpio.KeypadFactory()
    keypad = None
    disp = None

    def __init__(self, display):
        self.keypad = self.factory.create_keypad(keypad=self.KEYPAD, row_pins=self.ROW_PINS, col_pins=self.COL_PINS)
        self.keypad.registerKeyPressHandler(self.printKey)
        self.disp = display

    def printKey(self, key):
        self.disp.Escribir(key)
        print(key)

    def IniciarTeclado(self):
        print("Teclado Inicializado")
        try:
            while(True):
                time.sleep(0.5) #-- Este bucle es para evitar que el proceso de escucha del teclado termine
        except:
            self.keypad.cleanup()

''' Testing '''

'''
lcd = DisplayLCD()
lcd.InicializarDisplay()
lcd.BorrarPantalla()
teclado = Teclado(lcd)
teclado.IniciarTeclado()
'''



