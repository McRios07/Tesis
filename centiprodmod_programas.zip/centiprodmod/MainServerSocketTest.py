# encoding: utf-8

import socket
import sys
from pad4pi import rpi_gpio
from RPLCD.gpio import CharLCD
import RPi.GPIO as GPIO
import time
import threading
from TestNegocioCentiProd import Negocio
import subprocess
import datetime

class ServidorPrincipal:

    HOST = '' # all availabe interfaces
    PORT = 33000 # arbitrary non privileged port
    seguir = True
    listaClientes = []
    idNodoPrincipal = 0

#---------------------------------------------- Variables del Teclado
    KEYPAD = [
            ["7","8","9","F"],
            ["4","5","6","E"],
            ["1","2","3","D"],
            ["A","0","B","C"]
    ]
    
    '''
    ROW_PINS = [5,11,9,10] # BCM
    COL_PINS = [6,13,19,26] # BCM
    '''
    COL_PINS = [3,2,1,0] # BCM
    ROW_PINS = [4,5,6,7] # BCM
    factory = rpi_gpio.KeypadFactory()
    keypad = None

#---------------------------------------------- Variables del Display

    # Define GPIO to LCD mapping
    '''
    LCD_RS = 2
    LCD_E  = 3
    LCD_D4 = 4
    LCD_D5 = 17
    LCD_D6 = 27
    LCD_D7 = 22
    LED_ON = 22
    '''
    LCD_RS = 28
    LCD_E  = 29
    LCD_D4 = 30
    LCD_D5 = 31
    LCD_D6 = 32
    LCD_D7 = 33
    LED_ON = 33
    disp = None
    
#---------------------------------------------- Variables de Usuario
    capturoActualmente = "Usuario"
    lineaActualLcd = 0
    posicionActualLcd = 0
    numLoginBascula = 0
    usuarios = ["", "", "", ""]
    usuario = ""
    contrasena = ""
    loginValido = False
    indicadorEscrituraUsuario = ">"
    indicadorEscrituraContrasena = " "
    estadoValidacionB1 = "O"
    estadoValidacionB2 = "X"
    estadoValidacionB3 = "X"
    estadoValidacionB4 = "X"
    ultimoPesoB1 = ""
    ultimoPesoB2 = ""
    ultimoPesoB3 = ""
    ultimoPesoB4 = ""
    ipBascula1 = ""
    ipBascula2 = ""
    ipBascula3 = ""
    ipBascula4 = ""
    negocio = Negocio()


    def __init__(self):
        negocio = Negocio()
        self.ipBascula1 = negocio.ObtenerIpBascula(1)
        self.ipBascula2 = negocio.ObtenerIpBascula(2)
        self.ipBascula3 = negocio.ObtenerIpBascula(3)
        self.ipBascula4 = negocio.ObtenerIpBascula(4)

    def printKey(self, key):
        if key == "E":
            if self.capturoActualmente == "Usuario":
                self.capturoActualmente = "Contrasena"
                self.indicadorEscrituraUsuario = " "
                self.indicadorEscrituraContrasena = ">"
            else:
                self.capturoActualmente = "Usuario"
                self.indicadorEscrituraUsuario = ">"
                self.indicadorEscrituraContrasena = " "
        elif key == "C":
            pass
        elif key == "F":
            self.BorrarPantalla()
            self.Escribir("Reconfigurando.",0,0)
            self.Escribir("Por favor",1, 0)
            self.Escribir("Espere...", 2, 0)
            time.sleep(1)
            subprocess.call(["sudo", "reboot"])
            pass
        elif key == "B":
            #print(key, " ", self.usuario, " ", self.contrasena)
            self.BorrarPantalla()
            if self.capturoActualmente == "Usuario":
                self.usuario = self.usuario[:-1]
            else:
                self.contrasena = self.contrasena[:-1]
        #-- ///////////////////////////////////////////////////// PENDIENTE ENVIO AL NODO PRINCIPAL
        elif key == "A":
            print("Procesando envio")
            self.EnviarPendiente("@C@VL@" + str(self.usuario) + "@" + str(self.contrasena))
            pass
        #-- /////////////////////////////////////////////////////
        else:
            if self.capturoActualmente == "Usuario":
                self.usuario = self.usuario + str(key)
            else:
                self.contrasena = self.contrasena + str(key)

    def BorrarPantalla(self):
        self.disp.clear()

    def Escribir(self, texto, linea = 0, posicion = 0):
        self.disp.cursor_pos = (linea, posicion)
        self.disp.write_string(texto)

    def MostrarLogin(self,numBascula):
        self.Escribir("Bascula " + str(numBascula))
        self.Escribir(self.indicadorEscrituraUsuario + "Usuario:" + self.usuario, 1, 0)
        self.Escribir(self.indicadorEscrituraContrasena + "Clave  :" + self.contrasena, 2, 0)
        self.Escribir("B1:" + str(self.estadoValidacionB1) + "|B2:" + str(self.estadoValidacionB2) + "|B3:" + str(self.estadoValidacionB3) + "|B4:" + str(self.estadoValidacionB4) , 3, 0)

    def MostrarInfoProceso(self):
        self.Escribir("Up", 0, 0)
        self.Escribir("and listo", 1, 0)
        self.Escribir("pas crribir", 2, 0)
        self.Escribir("B1:" + str(self.estadoValidacionB1) + "|B2:" + str(self.estadoValidacionB2) + "|B3:" + str(self.estadoValidacionB3) + "|B4:" + str(self.estadoValidacionB4) , 3, 0)

    def IniciarEscucha(self):
        hMain = threading.Thread(target=self.MainThread)
        hMain.start()
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        except socket.error as e:
            print("[-] Al crear el socket del servidor: ", e)
            sys.exit(0)

        print("[-] Socket de Servidor Creado")

        # bind socket
        try:
            s.bind((self.HOST, self.PORT))
            print("[-] Socket atado al puerto " + str(self.PORT))
        except socket.error as e:
            print("[-] Al atar el puerto del socket: ", e)
            sys.exit()

        s.listen(10)

        print("[-] Servidor Escuchando...")
        while True:
            # blocking call, waits to accept a connection
            conn, addr = s.accept()
            print("[-] Cliente conectado en " + addr[0] + ":" + str(addr[1]))
            self.listaClientes.append(conn)
            hiloEscuchacliente = threading.Thread(self.client_thread, (conn,))
            hiloEscuchacliente.start()

#-- *******************************************************
#-- ******************************************************* PROCESAR RESPUESTA DEL NODO PRINCIPAL
    def ProcesarRespuestaNodoPrincipal(self, respuesta):
        print("Procese: " + str(respuesta))
        if "@A@Ten-four@LhT" in respuesta:
            info = respuesta.split('@')
            print("info: ", info)
            print("Esi gual?: ", str(info[4]) == str(self.usuario))
            if str(info[4]) == str(self.usuario):
                self.usuarios[self.numLoginBascula - 1] = self.usuario
                print("Usuarios: ", self.usuarios)
                print("Autenticado")
                self.usuario = ""
                self.contrasena = ""
                self.loginValido = True
                if self.numLoginBascula == 1: self.estadoValidacionB1 = "@"
                if self.numLoginBascula == 2: self.estadoValidacionB2 = "@"
                if self.numLoginBascula == 3: self.estadoValidacionB3 = "@"
                if self.numLoginBascula == 4: self.estadoValidacionB4 = "@"
        elif "@A@Ten-four@LhF" in respuesta:
            print("Login fallido")
        else:
            print("Too bad: Llegue aqui")

#-- *******************************************************
#-- *******************************************************

#-- $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#-- $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ COMUNICACION CON CLIENTES
    def client_thread(self, conn):
        while self.seguir:
            data = str(conn.recv(512))
            if data != "b''" and data != "''" and data != "":
                print("Enviando a todos los clientes...")
                if "Peso [" in data:
                    data = data.replace("Peso [", "").replace("]:", "").split()
                    ipSender = data[0]
                    pesoSender = data[1]
                    print("Sender: ", ipSender, " Peso:", pesoSender)

                self.ProcesarRespuestaNodoPrincipal(data)
                #-- Si algo llega de todos los clientes lo mando a todos los clientes conectados.
                #-- Solo lo recibira el nodo principal ya que es el unico habilitado para recibir
                ts = time.time()
                hora = str(datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S'))
                fecha = str(datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d'))
                self.negocio.RegistrarPesaje("", str(fecha) + " " + str(hora), str(data))
                for cliente in self.listaClientes:
                    cliente.sendall(str.encode(str(data)))
                print("Enviado a todos los clientes.")

    def EnviarPendiente(self, pendienteEnviar):
        if pendienteEnviar != "":
            print("Enviando: " + pendienteEnviar)
            for cliente in self.listaClientes:
                cliente.sendall(str.encode(str(pendienteEnviar)))

#-- $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#-- $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

    def PausarEscucha(self):
        self.seguir = False

    def ContinuarEscucha(self):
        self.seguir = True

    def MainThread(self):
        print("Iniciando teclado")
        self.keypad = self.factory.create_keypad(keypad=self.KEYPAD, row_pins=self.ROW_PINS, col_pins=self.COL_PINS)
        self.keypad.registerKeyPressHandler(self.printKey)
        print("Teclado Iniciado")
        print("Iniciando Display")
        time.sleep(2)
        self.disp = CharLCD(pin_rs=self.LCD_RS, pin_rw=self.LED_ON, pin_e=self.LCD_E,
                      pins_data=[self.LCD_D4, self.LCD_D5, self.LCD_D6, self.LCD_D7],
                      numbering_mode=GPIO.BCM,
                      cols=20, rows=4, dotsize=8,
                      charmap='A02', compat_mode=True,
                      auto_linebreaks=True)
        time.sleep(2)
        print("Display iniciado")

        while True:
            #-- Si no se han realizado logins
            if self.numLoginBascula <= 4:
                for i in range(1,6):
                    if self.numLoginBascula < i:
                        self.numLoginBascula = i
                        self.loginValido = False
                        print("Validando login de bascula: ", self.numLoginBascula)
                        if self.numLoginBascula > 4:
                            self.BorrarPantalla()
                            break
                        while self.loginValido == False:
                            self.MostrarLogin(self.numLoginBascula)
                            time.sleep(0.5)
            else: #-- Si ya se han realizado todos los login
                self.MostrarInfoProceso()
                time.sleep(1)

''' Testing '''
'''
svr = ServidorPrincipal()
svr.IniciarEscucha()
'''
