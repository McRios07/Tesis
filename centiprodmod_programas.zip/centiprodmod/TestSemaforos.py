import RPi.GPIO as GPIO
import time

#from gpiozero import TonalBuzzer
#from gpiozero.tones import Tone

class Torretas:

    RojoS1 = 5
    AmarilloS1 = 4
    VerdeS1 = 3
    RojoS2 = 2
    AmarilloS2 = 1
    VerdeS2 = 0
    RojoS3 = 28
    AmarilloS3 = 29
    VerdeS3 = 30
    RojoS4 = 31
    AmarilloS4 = 32
    VerdeS4 = 33
    RojoS5 = 34
    AmarilloS5 = 35
    VerdeS5 = 36
    RojoS6 = 37
    AmarilloS6 = 38
    VerdeS6 = 39
    RojoS7 = 40
    AmarilloS7 = 41
    VerdeS7 = 42
    RojoS8 = 43
    AmarilloS8 = 44
    VerdeS8 = 45

    numeroTorreta = 1


    def __init__(self, numero):
        print("Peticion para la torreta: " + str(numero))
        self.numeroTorreta = numero
        self.InicializarTorreta()
        pass

    def InicializarTorreta(self):
        #GPIO.cleanup()
        GPIO.setwarnings(False)
        GPIO.setmode(GPIO.BCM)
        if self.numeroTorreta == 1:
            GPIO.setup(self.RojoS1, GPIO.OUT) #Luz Rojo S1
            GPIO.setup(self.AmarilloS1, GPIO.OUT) #Luz Amarillo S1
            GPIO.setup(self.VerdeS1, GPIO.OUT) #Luz Verde S1
        elif self.numeroTorreta == 2:
            GPIO.setup(self.RojoS2, GPIO.OUT) #Luz Rojo S2
            GPIO.setup(self.AmarilloS2, GPIO.OUT) #Luz Amarillo S2
            GPIO.setup(self.VerdeS2, GPIO.OUT) #Luz Verde S2
        elif self.numeroTorreta == 3:
            GPIO.setup(self.RojoS3, GPIO.OUT) #Luz Rojo S3
            GPIO.setup(self.AmarilloS3, GPIO.OUT) #Luz Amarillo S3
            GPIO.setup(self.VerdeS3, GPIO.OUT) #Luz Verde S3
        elif self.numeroTorreta == 4:
            GPIO.setup(self.RojoS4, GPIO.OUT) #Luz Rojo S4
            GPIO.setup(self.AmarilloS4, GPIO.OUT) #Luz Amarillo S4
            GPIO.setup(self.VerdeS4, GPIO.OUT) #Luz Verde S4
        elif self.numeroTorreta == 5:
            GPIO.setup(self.RojoS5, GPIO.OUT) #Luz Rojo S5
            GPIO.setup(self.AmarilloS5, GPIO.OUT) #Luz Amarillo S5
            GPIO.setup(self.VerdeS5, GPIO.OUT) #Luz Verde S5
        elif self.numeroTorreta == 6:
            GPIO.setup(self.RojoS6, GPIO.OUT) #Luz Rojo S6
            GPIO.setup(self.AmarilloS6, GPIO.OUT) #Luz Amarillo S6
            GPIO.setup(self.VerdeS6, GPIO.OUT) #Luz Verde S6
        elif self.numeroTorreta == 7:
            GPIO.setup(self.RojoS7, GPIO.OUT) #Luz Rojo S7
            GPIO.setup(self.AmarilloS7, GPIO.OUT) #Luz Amarillo S7
            GPIO.setup(self.VerdeS7, GPIO.OUT) #Luz Verde S7
        else:
            GPIO.setup(self.RojoS8, GPIO.OUT) #Luz Rojo S8
            GPIO.setup(self.AmarilloS8, GPIO.OUT) #Luz Amarillo S8
            GPIO.setup(self.VerdeS8, GPIO.OUT) #Luz Verde S8

    #b = TonalBuzzer(26)


    def ApagarSemaforos(self):
        #Apago todos los semaforos
        if self.numeroTorreta == 1:
            GPIO.output(self.RojoS1, GPIO.LOW) #Luz Rojo S1
            GPIO.output(self.AmarilloS1, GPIO.LOW) #Luz Amarillo S1
            GPIO.output(self.VerdeS1, GPIO.LOW) #Luz Verde S1
        elif self.numeroTorreta == 2:
            GPIO.output(self.RojoS2, GPIO.LOW) #Luz Rojo S2
            GPIO.output(self.AmarilloS2, GPIO.LOW) #Luz Amarillo S2
            GPIO.output(self.VerdeS2, GPIO.LOW) #Luz Verde S2
        elif self.numeroTorreta == 3:
            GPIO.output(self.RojoS3, GPIO.LOW) #Luz Rojo S3
            GPIO.output(self.AmarilloS3, GPIO.LOW) #Luz Amarillo S3
            GPIO.output(self.VerdeS3, GPIO.LOW) #Luz Verde S3
        elif self.numeroTorreta == 4:
            GPIO.output(self.RojoS4, GPIO.LOW) #Luz Rojo S4
            GPIO.output(self.AmarilloS4, GPIO.LOW) #Luz Amarillo S4
            GPIO.output(self.VerdeS4, GPIO.LOW) #Luz Verde S4
        elif self.numeroTorreta == 5:
            GPIO.output(self.RojoS5, GPIO.LOW) #Luz Rojo S5
            GPIO.output(self.AmarilloS5, GPIO.LOW) #Luz Amarillo S5
            GPIO.output(self.VerdeS5, GPIO.LOW) #Luz Verde S5
        elif self.numeroTorreta == 6:
            GPIO.output(self.RojoS6, GPIO.LOW) #Luz Rojo S6
            GPIO.output(self.AmarilloS6, GPIO.LOW) #Luz Amarillo S6
            GPIO.output(self.VerdeS6, GPIO.LOW) #Luz Verde S6
        elif self.numeroTorreta == 7:
            GPIO.output(self.RojoS7, GPIO.LOW) #Luz Rojo S7
            GPIO.output(self.AmarilloS7, GPIO.LOW) #Luz Amarillo S7
            GPIO.output(self.VerdeS7, GPIO.LOW) #Luz Verde S7
        else:
            GPIO.output(self.RojoS8, GPIO.LOW) #Luz Rojo S8
            GPIO.output(self.AmarilloS8, GPIO.LOW) #Luz Amarillo S8
            GPIO.output(self.VerdeS8, GPIO.LOW) #Luz Verde S8


    def EncenderLuzSemaforo(self, color):
        self.ApagarSemaforos()
        if self.numeroTorreta == 1:
            if color == "rojo": GPIO.output(self.RojoS1, GPIO.HIGH)
            elif color == "amarillo": GPIO.output(self.AmarilloS1, GPIO.HIGH)
            else: GPIO.output(self.VerdeS1, GPIO.HIGH)
        elif self.numeroTorreta == 2:
            if color == "rojo": GPIO.output(self.RojoS2, GPIO.HIGH)
            elif color == "amarillo": GPIO.output(self.AmarilloS2, GPIO.HIGH)
            else: GPIO.output(self.VerdeS2, GPIO.HIGH)
        elif self.numeroTorreta == 3:
            if color == "rojo": GPIO.output(self.RojoS3, GPIO.HIGH)
            elif color == "amarillo": GPIO.output(self.AmarilloS3, GPIO.HIGH)
            else: GPIO.output(self.VerdeS3, GPIO.HIGH)
        elif self.numeroTorreta == 4:
            if color == "rojo": GPIO.output(self.RojoS4, GPIO.HIGH)
            elif color == "amarillo": GPIO.output(self.AmarilloS4, GPIO.HIGH)
            else: GPIO.output(self.VerdeS4, GPIO.HIGH)
        elif self.numeroTorreta == 5:
            if color == "rojo": GPIO.output(self.RojoS5, GPIO.HIGH)
            elif color == "amarillo": GPIO.output(self.AmarilloS5, GPIO.HIGH)
            else: GPIO.output(self.VerdeS5, GPIO.HIGH)
        elif self.numeroTorreta == 6:
            if color == "rojo": GPIO.output(self.RojoS6, GPIO.HIGH)
            elif color == "amarillo": GPIO.output(self.AmarilloS6, GPIO.HIGH)
            else: GPIO.output(self.VerdeS6, GPIO.HIGH)
        elif self.numeroTorreta == 7:
            if color == "rojo": GPIO.output(self.RojoS7, GPIO.HIGH)
            elif color == "amarillo": GPIO.output(self.AmarilloS7, GPIO.HIGH)
            else: GPIO.output(self.VerdeS7, GPIO.HIGH)
        else:
            if color == "rojo": GPIO.output(self.RojoS8, GPIO.HIGH)
            elif color == "amarillo": GPIO.output(self.AmarilloS8, GPIO.HIGH)
            else: GPIO.output(self.VerdeS8, GPIO.HIGH)

'''
    def PlayTono():
        #if b.is_active == False:
        b.play(Tone("A4"))
        b.play(Tone(500.0)) # Hz
        b.play(Tone(midi=60)) # middle C in MIDI notation
        b.play("A4")
        b.play(500.0)
        b.play(Tone(midi=60))


while True:
    PlayTono()

'''

numSemaforo = 1
colores = ["rojo", "amarillo", "verde" ]
torretas = Torretas(numSemaforo)
torretas.ApagarSemaforos()
#torretas.EncenderLuzSemaforo("verde")

while True:
    for color in colores:
        print ("semaforo: " + str(numSemaforo) + " color:" + color)
        torretas.EncenderLuzSemaforo(color)
        time.sleep(2)
        #PlayTono()





