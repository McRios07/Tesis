import RPi.GPIO as GPIO
from RPLCD.gpio import CharLCD
import time
from pad4pi import rpi_gpio
import serial
import re
import socket
import threading
import errno
import sqlite3
import sys
from collections import Counter
import datetime

GPIO.setwarnings(False) #Omito los warnings de la consola


#-------------------------------------------------------------------VARIABLES GLOBALES
#-- Variables de peso
pesoActual = "" # peso que actualmente tiene el indicador
pesoThreshold = 0.0 # nivel de peso que se debe rebasar para asumir que hay peso sobre la bascula
listaPesos = [] # Lista que almacena los pesos que se van recibiendo del indicador
subioDeCero = False # Si el peso ha subido de cero.
pesoModa = 0.0 # Peso que se repitio mas en la lista de pesos
producto = "" #Nombre del producto que actualmente procesa la bascula
descripcionProducto = "" #Descripcion del producto que actualmente procesa a bascula
#Limites de peso o SETPOINTS
spLow = 0.0
spUnder = 0.0
spOver = 0.0
spHigh = 0.0
spTara = 0.0
heInicializado = False # Si se ha recibido la configuracion de producto y setpoints
nivelPesoActual = "LOW"
nivelPesoEnModa = "LOW"

#Configuraciones del servidor TCP
bind_ip = '192.168.254.9'
bind_port = 2101
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((bind_ip, bind_port))
server.listen(5)  # max backlog of connections
hayPeticionEnvio = False # Si hay una peticion para enviar informacion al Nodo principal
deboEnviarYEsperar = False # Si debo o no esperar por una respuesta del Nodo pricipal al enviarle un dato
client_socket = None

#Configuraciones del login
nivelCapturaLogin = "usuario" # El dato que se esta capturando actualmente con el teclado
datosLoginPreparados = False # Si los datos de login estan preparados paraenviarse al nodo principal para validarse
datosLoginValidados = False # Si el nodo principal ha validadao los datos de login
contrasena = "" #Contrasena Capturada por el teclado
usuario = "" #Usuario capturado por el teclado y que se usa para identificar al usuario actual si es confirmado por el nodo principal
bascula = "" #Numero de bascula
grupo = "" #Numero de grupo


esperarRespuesta = True #debo esperar respuesta del nodo principal
datoEnviar = "" #Dato que se le debe enviar al nodo principal
deboReinicializarConexion = True #debo re inicializar nuevamente el servidor TCP (por si se desconecta el nodo principal)
estoyPreparado = False #Si el sistema esta preparado para enviar informacion al Nodo principal
db = None #Base de datos que utilza el sistema
deboLeerSerial = False # Si debo o no leer del puerto serial
deboMostrarNivelesTorreta = False

#Variables del Display
disp = None
borrarDisplay = False

#--------------------------------------------------------------------------------------------------------------------------------------------


#-------------------------------------------------------------------RUTINA DEL LA BASE DE DATOS

def ConectarBaseDatos():
    global db
    db = sqlite3.connect('/home/pi/Desktop/python/cfg')
    c = db.cursor()
    return c


def GuardarConfig(config, valor):
    global db
    c = ConectarBaseDatos()
    c.execute("UPDATE Configuracion SET Valor='" + str(valor)  + "' WHERE Configuracion = '" + str(config) + "'")
    db.commit()


def ObtenerConfig(config):
    c = ConectarBaseDatos()
    #print("SELECT Valor FROM Configuracion WHERE Configuracion = '" + str(config) + "'")
    c.execute("SELECT Valor FROM Configuracion WHERE Configuracion = '" + str(config) + "'")
    valor = c.fetchone()
    return valor[0]

def CargarSetpoints():
    global spLow, spUnder, spOver, spHigh, spTara, producto, heInicializado
    setpoints = ObtenerConfig("Setpoints").split(",")
    print(setpoints)
    spLow = float(setpoints[0])
    spUnder = float(setpoints[1])
    spOver = float(setpoints[2])
    spHigh = float(setpoints[3])
    spTara = float(setpoints[4])
    producto = setpoints[5]
    heInicializado = True

def CargarProducto():
    global producto
    producto = ObtenerConfig("Producto")
    print("Producto: " + str(producto))


#--------------------------------------------------------------------------------------------------------------------------------------------


#-------------------------------------------------------------------RUTINA DEL DISPLAY LCD
# Define GPIO to LCD mapping
def InicializarDisplay():
    global disp
    LCD_RS = 2
    LCD_E  = 3
    LCD_D4 = 4
    LCD_D5 = 17
    LCD_D6 = 27
    LCD_D7 = 22
    LED_ON = 22

    disp = CharLCD(pin_rs=LCD_RS, pin_rw=LED_ON, pin_e=LCD_E, pins_data=[LCD_D4, LCD_D5, LCD_D6, LCD_D7],
                  numbering_mode=GPIO.BCM,
                  cols=20, rows=4, dotsize=8,
                  charmap='A02', compat_mode=True,
                  auto_linebreaks=True)

def BorrarDisplay():
    global borrarDisplay
    if borrarDisplay == True:
        disp.clear()
        borrarDisplay = False

#--------------------------------------------------------------------------------------------------------------------------------------------


#-------------------------------------------------------------------RUTINA QUE CONTROLA LA CONEXION DEL SERVIDOR TCP


def ManejardorConexionRed():
    global datoEnviar, deboReinicializarConexion, client_socket, hayPeticionEnvio
    while True:
        try:
            if hayPeticionEnvio == True:
                hayPeticionEnvio = False
                time.sleep(0.5)
                if(deboEnviarYEsperar): #-- Si debo de enviar un dato al Nodo Principal y esperar una respuesta
                    print("Esperando al nodo principal")
                    client_socket.send(datoEnviar)
                    request = client_socket.recv(1024)
                    client_socket.send('*')
                    ProcesarRespuestaNodoPrincipal(request)
                else:
                    print("Enviado al nodo principal")
                    client_socket.send(datoEnviar)

                datoEnviar = ""
                time.sleep(0.5)

            else:
                #print("Nada Para enviar")
                pass
        except socket.error as e:
            if isinstance(e.args, tuple):
                if e[0] == errno.EPIPE:
                   # remote peer disconnected
                   print "Nodo principal desconectado"
                else:
                    pass
            else:
                print "Error de Socket " + e
            deboReinicializarConexion = True
            client_socket.close()
            break
        except IOError as e:
            print "IOError: " + e
            client_socket.close()
            deboReinicializarConexion = True
            break

def IniciarManejadorConexionRed():
    global client_socket
    client_socket, address = server.accept()
    print 'Conexion aceptada de {}:{}'.format(address[0], address[1])
    client_handler = threading.Thread(target=ManejardorConexionRed)
    client_handler.start()
#--------------------------------------------------------------------------------------------------------------------------------------------
#Armando Ariza

#-------------------------------------------------------------------RUTINA DE LA TORRETA


def MostrarNivelEnTorreta(peso):
    #print(peso)
    pass



#-------------------------------------------------------------------RUTINA QUE CONTROLA EL TECLADO
KEYPAD = [
        ["7","8","9","F"],
        ["4","5","6","E"],
        ["1","2","3","D"],
        ["A","0","B","C"]
]

COL_PINS = [5,11,9,10] # BCM numbering
ROW_PINS = [6,13,19,26] # BCM numbering

factory = rpi_gpio.KeypadFactory()
# Hilo principal del teclado
keypad = factory.create_keypad(keypad=KEYPAD, row_pins=ROW_PINS, col_pins=COL_PINS)


def ReiniciarCapturaLogin():
    global usuario, contrasena, nivelCapturaLogin, datosLoginPreparados, datosLoginValidados, heInicializado
    heInicializado = False
    datosLoginValidados = False
    datosLoginPreparados = False
    contrasena = usuario = ""
    nivelCapturaLogin = "usuario"
    #Apago todas las luces de la torreta
    GPIO.output(27,GPIO.LOW)
    GPIO.output(22,GPIO.LOW)
    GPIO.output(5,GPIO.LOW)
    #time.sleep(0.2) # Esto es necesario el sistema funciona muy rapido


def printKey(key):
    global usuario, contrasena, nivelCapturaLogin, datosLoginPreparados, heInicializado
    #print("Presione " + key)
    if heInicializado == True:
        if key == 'E': #Si recibo 'E' cambia la captura de campos usuario-contrasena-preparadoParaLogin
            if nivelCapturaLogin == "usuario":
                nivelCapturaLogin = "contrasena"
            elif nivelCapturaLogin == "contrasena":
                nivelCapturaLogin = "loginCapturado"
            elif nivelCapturaLogin == "loginCapturado":
                datosLoginPreparados = True
            print("Capturo: " + nivelCapturaLogin)
        elif key == 'C':  #Si recibo 'C' Cancelo la captura de login actual e inicio desde la captura de usuario
            ReiniciarCapturaLogin()
        elif key == 'F': #Si recibo 'F' Cierro la sesion actual y espero una nueva configuracion del Nodo principal
            ReiniciarCapturaLogin()
            heInicializado = False
        else:
            if nivelCapturaLogin == "usuario":
                usuario = usuario + key
                #print("Escribo usuario.")
            elif nivelCapturaLogin == "contrasena":
                contrasena = contrasena + key
                #print("Escribo contrasena.")
            elif nivelCapturaLogin == "loginCapturado":
                pass

        print ("Usuario: " + usuario + " Contasena: " + contrasena)

# printKey Sera llamado cada vez que se presione una tecla
keypad.registerKeyPressHandler(printKey)

#------------------------------------------------------------------------------------------------------------------------


#-------------------------------------------------------------------RUTINA QUE CONTROLA EL PUERTO SERIAL

ser = serial.Serial(
       port='/dev/ttyUSB0',
       baudrate = 9600,
       parity=serial.PARITY_NONE,
       stopbits=serial.STOPBITS_ONE,
       bytesize=serial.EIGHTBITS,
       timeout=1
   )


def getNumbers(strg):
    array = re.findall(r'[0-9\-.]+', strg)
    return array


def EncontrarModa(lst):
    #print("buscando moda")
    resp = max(set(lst), key = lst.count)
    #print ("modadef: " + str(resp))
    return resp


def ProcesarPeso(peso):
    global pesoThreshold, subioDeCero, listaPesos, nivelPesoActual, nivelPesoEnModa
    #print("Peso: " + str(peso))
    if peso > pesoThreshold and subioDeCero == False:
        subioDeCero = True
        print("subi de dero")

    if peso > pesoThreshold:
        listaPesos.append(peso)
        #print("Agregue: " + str(peso))

    if len(listaPesos) > 100:
        #print("borre: " + str(listaPesos[0]))
        del listaPesos[0]

    #print("peso: " + str(peso) + " subioDeCero: " + str(subioDeCero))
    if peso <= 0 and subioDeCero == True:
        tmpModa = EncontrarModa(listaPesos)
        #print("Moda: " + str(tmpModa))
        del listaPesos[:]
        subioDeCero = False
        time.sleep(0.2)
        print ("Envie moda")
        nivelPesoEnModa = nivelPesoActual
        return tmpModa

    return 0.0

def ObtenerPeso():
    global ser, pesoActual, estoyPreparado, spTara, client_socket, nivelPesoEnModa
    while True:
        try:
            if deboLeerSerial:
                byt = ser.readline()
                pesoActual = getNumbers(str(byt))[0]
                if deboMostrarNivelesTorreta:
                    MostrarNivelEnTorreta(float(pesoActual))
                #if float(pesoActual) > 0:
                #print("Peso: " + pesoActual)
                moda = ProcesarPeso(float(pesoActual))
                #print ("ModaR:" + str(moda))
                if float(moda) > 0:# Si este valor es mayor que cero entonces el nivel del peso subio y bajo a cero
                    print("Enviare: " + str(moda))
                    ts = time.time()
                    hora = str(datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S'))
                    fecha = str(datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d'))
                    client_socket.send("#1#1#0001#" +  str(moda) + "#kg#" + hora + "#" + fecha + "#" + nivelPesoEnModa +"##" + str(spTara) )
                    print("Envie este peso: " + str(moda))
                    nivelPesoEnModa = "LOW"
        except:
            #-- Cuando el indicador no entrega una cadena legible
            pass

def IniciarManejadorPuertoSerial():
    # Hilo principal del puerto serial
    serial_handler = threading.Thread(target=ObtenerPeso)
    serial_handler.start()
#------------------------------------------------------------------------------------------------------------------------


#--------------------------------------------------------------------------- FUNCIONES DE TRANSACCION

def ProcesarRespuestaNodoPrincipal(respuesta):
    global estoyPreparado, usuario, contrasena, escriboActualmente, disp, datosLoginValidados, hayPeticionEnvio, datoEnviar
    hayPeticionEnvio = False
    datoEnviar = ""
    print("Recibi: " + respuesta)
    if "@Ten-four@LhT" in respuesta: #Si el login es correcto.
        datosLoginValidados = True
        print("Validado")
        return

    if "@Ten-four@LhF" in respuesta: #Si el login es incorrecto
        datosLoginValidados = False
        ReiniciarCapturaLogin()
        print("No validado")
        return

    if "@sp" in respuesta:
        sp = respuesta.replace("@sp", "")
        GuardarConfig("Setpoints", sp)
        CargarSetpoints() # Este proceso guarda los Setpoints recibidos del Nodo principal
        return

    #if "@pd" in respuesta:
        #pd = respuesta.replace("@pd", "")
        #GuardarConfig("Producto", pd)
        #CargarSetpoints() # Este proceso guarda los Setpoints recibidos del Nodo principal
        #return

    print("Alcance esto")

def SolicitarDatosPoducto():
    global datoEnviar, hayPeticionEnvio, disp, deboEnviarYEsperar

    disp.cursor_pos = (0, 0)
    disp.write_string("Conectado.")
    disp.cursor_pos = (1, 0)
    disp.write_string("Esperando")
    disp.cursor_pos = (2, 0)
    disp.write_string("configuracion")
    datoEnviar = "@gSP"
    deboEnviarYEsperar = True
    hayPeticionEnvio = True


def MostrarUsuarioContrasena():
    global usuario, contrasena, disp

    disp.cursor_pos = (0, 0)
    disp.write_string("Usuario   : " + usuario)
    disp.cursor_pos = (1, 0)
    disp.write_string("Contrasena: " + contrasena)


def SolicitarValidacionLogin():
    global datoEnviar, hayPeticionEnvio, disp, usuario, contrasena, deboEnviarYEsperar
    #disp.clear()
    disp.cursor_pos = (0, 0)
    disp.write_string("Esperando.")
    disp.cursor_pos = (1, 0)
    disp.write_string("Autenticacion")
    datoEnviar = "@vUP" + usuario + "," + contrasena
    deboEnviarYEsperar = True
    hayPeticionEnvio = True


def InicializarDispositivo():
    global disp
    print("Esperando nueva conexion...")
    #disp.clear()
    disp.cursor_pos = (0, 0)
    disp.write_string("Esperando conexion")
    disp.cursor_pos = (1, 0)
    disp.write_string("con el nodo ")
    disp.cursor_pos = (2, 0)
    disp.write_string("principal...")


#----------------------------------------------------------------------------------------------------------------


#--------------------------------------------------------------------------------- BUCLE PRINCIPAL
def main():
    global heInicializado, datosLoginPreparados, datosLoginValidados, disp, deboLeerSerial, deboMostrarNivelesTorreta
    if heInicializado == True:
        if datosLoginPreparados == True:
            SolicitarValidacionLogin()
        else:
            MostrarUsuarioContrasena()

        if datosLoginValidados == True:
            deboLeerSerial = True
            deboMostrarNivelesTorreta = True

    else:
        SolicitarDatosPoducto()
    time.sleep(0.2) # Esto es necesario el sistema funciona muy rapido

# Inicializacion
InicializarDisplay()
InicializarDispositivo()
IniciarManejadorPuertoSerial()
IniciarManejadorConexionRed()

while heInicializado == False:
    SolicitarDatosPoducto()
    time.sleep(0.5)

print("Producto configurado")
print("----")
print("Escribir Login")
while datosLoginValidados == False:
    MostrarUsuarioContrasena()
    time.sleep(0.5)
    if datosLoginPreparados == True:
        SolicitarValidacionLogin()

print("Login Correcto. ")

deboLeerSerial = True
deboMostrarNivelesTorreta = True
print("Inicalizacion correcta. Funcionando")


'''
# Solicitud de configuracion
SolicitarDatosPoducto()

#while datosLoginPreparados == False:
MostrarUsuarioContrasena()



while datosLoginValidados == False:
    SolicitarValidacionLogin()


print("Inicializado.")






try:
    InicializarDispositivo()
    IniciarManejadorPuertoSerial()
    IniciarManejadorConexionRed()
    while True:
        main()
except:
        print("Unexpected error:", sys.exc_info()[1])
        GPIO.cleanup()
'''