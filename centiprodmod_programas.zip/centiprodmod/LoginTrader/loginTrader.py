import RPi.GPIO as GPIO
from RPLCD.gpio import CharLCD
import time
from pad4pi import rpi_gpio
import serial
import re
import socket
import threading
import errno
import sqlite3
import sys


#-- Variables de peso
pesoActual = ""


#Configuraciones del servidor TCP
bind_ip = '192.168.254.9'
bind_port = 2101

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((bind_ip, bind_port))
server.listen(5)  # max backlog of connections


escriboActualmente = 0
contrasena = ""
usuario = ""
bascula = ""
grupo = ""
producto = ""
descripcionProducto = ""
spLow = 0.0
spUnder = 0.0
spOver = 0.0
spHigh = 0.0
spTara = 0.0

esperarRespuesta = True #debo esperar respuesta del nodo principal
datoEnviar = "" #Dato que se le debe enviar al nodo principal
deboReinicializarConexion = True #debo re inicializar nuevamente el servidor TCP (por si se desconecta el nodo principal)
estoyPreparado = False #Si el sistema esta preparado para enviar informacion al Nodo principal
db = None

GPIO.setwarnings(False) #Omito los warnings

#Salidas de la torreta
GPIO.cleanup()
GPIO.setmode(GPIO.BCM)
GPIO.setup(27, GPIO.OUT) #Luz Inferior
GPIO.setup(22, GPIO.OUT) #Luz Intermedia
GPIO.setup(5, GPIO.OUT) #Luz Superior

#Por default pongo las luces apagadas
GPIO.output(27,GPIO.LOW)
GPIO.output(22,GPIO.LOW)
GPIO.output(5,GPIO.LOW)


# Define GPIO to LCD mapping
LCD_RS = 24
LCD_E  = 25
LCD_D4 = 8
LCD_D5 = 7
LCD_D6 = 12
LCD_D7 = 16
LED_ON = 15

disp = CharLCD(pin_rs=LCD_RS, pin_rw=LED_ON, pin_e=LCD_E, pins_data=[LCD_D4, LCD_D5, LCD_D6, LCD_D7],
              numbering_mode=GPIO.BCM,
              cols=20, rows=4, dotsize=8,
              charmap='A02', compat_mode=True,
              auto_linebreaks=True)



teclado = ""
'''
KEYPAD = [
        ["7","8","9","F"],
        ["4","5","6","E"],
        ["1","2","3","D"],
        ["A","0","B","C"]
]
'''
KEYPAD = [
        ["7","4","1","A"],
        ["8","5","2","0"],
        ["9","6","3","B"],
        ["F","E","D","C"]
]

COL_PINS = [17,4,3,2] # BCM numbering
ROW_PINS = [6,13,19,26] # BCM numbering

factory = rpi_gpio.KeypadFactory()
keypad = factory.create_keypad(keypad=KEYPAD, row_pins=ROW_PINS, col_pins=COL_PINS)
#keypad.cleanup()

ser = serial.Serial(
       port='/dev/ttyUSB0',
       baudrate = 9600,
       parity=serial.PARITY_NONE,
       stopbits=serial.STOPBITS_ONE,
       bytesize=serial.EIGHTBITS,
       timeout=1
   )


def ConectarBaseDatos():
    global db
    db = sqlite3.connect('/home/pi/Desktop/python/cfg')
    c = db.cursor()
    return c


def GuardarConfig(config, valor):
    global db
    c = ConectarBaseDatos()
    c.execute("UPDATE Configuracion SET Valor='" + str(valor)  + "' WHERE Configuracion = '" + str(config) + "'")
    db.commit()


def ObtenerConfig(config):
    c = ConectarBaseDatos()
    #print("SELECT Valor FROM Configuracion WHERE Configuracion = '" + str(config) + "'")
    c.execute("SELECT Valor FROM Configuracion WHERE Configuracion = '" + str(config) + "'")
    valor = c.fetchone()
    return valor[0]


def EnviarLogin():
    global usuario, contrasena
    print("EnviarLogin")
    EnviarYEsperarANodoPrincipal("@" + usuario + "@" + contrasena + "@Lh")


def ProcesarRespuestaNodoPrincipal(respuesta):
    global estoyPreparado, usuario, contrasena, escriboActualmente, disp
    print("Recibi: " + respuesta)
    if respuesta == "@Ten-four@LhT": #Si el login es correcto.
        disp.clear()
        disp.cursor_pos = (0, 0)
        disp.write_string("B: " + bascula + " G: " + grupo)
        disp.cursor_pos = (1, 0)
        disp.write_string("P: " + producto)
        estoyPreparado = True
        return

    if respuesta == "@Ten-four@LhF": #Si el login es incorrecto
        estoyPreparado = False
        usuario = ""
        contrasena = ""
        escriboActualmente = 0
        disp.clear()
        MostrarUsuarioContrasena()
        disp.cursor_pos = (3, 0)
        disp.write_string("Error Login. Reintentar")
        return

    if "@sp" in respuesta:
        sp = respuesta.replace("@sp", "")
        GuardarConfig("Setpoints", sp)
        CargarSetpoints()
        EnviarYEsperarANodoPrincipal("*@SP")
        return

def handle_client_connection(client_socket):
    global datoEnviar, deboReinicializarConexion
    while True:
        try:
            if(datoEnviar != ""):
                if(datoEnviar.endswith("+>")): #-- Si debo de enviar un dato al Nodo Principal y esperar una respuesta
                    client_socket.send(datoEnviar)
                    request = client_socket.recv(1024)
                    client_socket.send('*')
                    ProcesarRespuestaNodoPrincipal(request)

                if(datoEnviar.endswith("->")):
                    client_socket.send(datoEnviar)

                datoEnviar = ""
        except socket.error, e:
            if isinstance(e.args, tuple):
                #print "numerr es %d" % e[0]
                if e[0] == errno.EPIPE:
                   # remote peer disconnected
                   print "Nodo principal desconectado"
                else:
                    pass
            else:
                print "Error de Socket ", e
            deboReinicializarConexion = True
            client_socket.close()
            break
        except IOError, e:
            print "IOError: ", e
            client_socket.close()
            deboReinicializarConexion = True
            break


def printKey(key):
    global usuario, contrasena, escriboActualmente
    print("Recibi: " + key)
    if(key == 'E'):
        if escriboActualmente == 0:
            escriboActualmente = 1
        elif escriboActualmente == 1:
            EnviarLogin() #-- Si ya escribi el usurio la contrasena, envio la info al nodo principal para revisarla
            escriboActualmente = 0
    else:
        if(escriboActualmente == 0):
            usuario = usuario + key
            print("Escribo usuario.")
        else:
            contrasena = contrasena + key
            print("Escribo contrasena.")

# printKey Sera llamado cada vez que se presione una tecla
keypad.registerKeyPressHandler(printKey)


def getNumbers(strg):
    array = re.findall(r'[0-9\-.]+', strg)
    return array


def VerificarEscuchaServidor():
    global deboReinicializarConexion, disp
    if(deboReinicializarConexion):
        #inicializo el servidor TCP
        print("Esperando nueva conexion...")
        disp.clear()
        disp.cursor_pos = (0, 0)
        disp.write_string("Esperando conexion")
        disp.cursor_pos = (1, 0)
        disp.write_string("con el nodo ")
        disp.cursor_pos = (2, 0)
        disp.write_string("principal...")
        client_sock, address = server.accept()
        print 'Conexion aceptada de {}:{}'.format(address[0], address[1])
        disp.clear()
        client_sock.send("@up and ready baby!")
        client_sock.send("@" + str(bascula) + "@" + str(grupo) + "@" + str(producto) + "@>>")
        client_handler = threading.Thread(
            target=handle_client_connection,
            args=(client_sock,)
        )
        client_handler.start()
        deboReinicializarConexion = False


def MostrarNivelEnTorreta(peso):
    #print(peso)
    global spLow, spUnder, spOver, spHigh
    if(peso <= spUnder):
        GPIO.output(27,GPIO.HIGH)
        GPIO.output(22,GPIO.LOW)
        GPIO.output(5,GPIO.LOW)
    elif(peso > spUnder and peso < spOver):
        GPIO.output(27,GPIO.LOW)
        GPIO.output(22,GPIO.HIGH)
        GPIO.output(5,GPIO.LOW)
    elif(peso >= spOver):
        GPIO.output(27,GPIO.LOW)
        GPIO.output(22,GPIO.LOW)
        GPIO.output(5,GPIO.HIGH)


def handle_serial():
    global ser, pesoActual, estoyPreparado
    while True:
        try:
            if estoyPreparado:
                byt = ser.readline()
                pesoActual = getNumbers(str(byt))[0]
                MostrarNivelEnTorreta(float(pesoActual))
                if float(pesoActual) > 0:
                    EnviarANodoPrincipal(str(pesoActual))
                #print(pesoActual)
        except:
            #-- Cuando el indicador no entrega una cadena legible
            pass


def IniciarEscuchaSerial():
    serial_handler = threading.Thread(
            target=handle_serial
        )
    serial_handler.start()


def MostrarUsuarioContrasena():
    global usuario, contrasena, disp, estoyPreparado
    if estoyPreparado == False:
        disp.cursor_pos = (0, 0)
        disp.write_string("Usuario   : " + usuario)
        disp.cursor_pos = (1, 0)
        disp.write_string("Contrasena: " + contrasena)


def MostrarInfoPantalla():
    global deboReinicializarConexion
    if deboReinicializarConexion == False:
        MostrarUsuarioContrasena()


def EnviarANodoPrincipal(info):
    global datoEnviar
    datoEnviar = info + "->"


def EnviarYEsperarANodoPrincipal(info):
    global datoEnviar
    datoEnviar = info + "+>"

def EnviarDatosDisponiblesANodoPrincipal():
    #if dato != "":
    #    EnviarANodoPrincipal()
    pass

def CargarSetpoints():
    global spLow, spUnder, spOver, spHigh, spTara
    setpoints = ObtenerConfig("Setpoints").split(",")
    print(setpoints)
    spLow = float(setpoints[0])
    spUnder = float(setpoints[1])
    spOver = float(setpoints[2])
    spHigh = float(setpoints[3])
    spTara = float(setpoints[4])

def Inicializar():
    global bascula, grupo, producto, spLow, spUnder, spOver, spHigh, spTara, descripcionProducto
    bascula = ObtenerConfig("NumBascula")
    grupo = ObtenerConfig("Grupo")
    producto = ObtenerConfig("Producto")
    CargarSetpoints()
    descripcionProducto = ObtenerConfig("DescripcionProducto")
    IniciarEscuchaSerial()


def main():
    MostrarInfoPantalla()
    VerificarEscuchaServidor()



#-- Ciclo principal del programa
try:
    Inicializar()
    while True:
        main()
        time.sleep(0.2)
         #   pass
except:
    print("Unexpected error:", sys.exc_info()[1])
    GPIO.cleanup()



import RPi.GPIO as GPIO
import time

#Salidas de la torreta
GPIO.cleanup()
GPIO.setmode(GPIO.BCM)
GPIO.setup(10, GPIO.OUT) #Luz Verde
GPIO.setup(9, GPIO.OUT) #Luz Amarillo
GPIO.setup(11, GPIO.OUT) #Luz Rojo
GPIO.setup(14, GPIO.OUT) #Activacion de semaforo 1
GPIO.setup(15, GPIO.OUT) #Activacion de semaforo 2
GPIO.setup(18, GPIO.OUT) #Activacion de semaforo 3
GPIO.setup(23, GPIO.OUT) #Activacion de semaforo 4


def DesactivarControladores():
    #Quito la activacion de todos los semaforos
    GPIO.output(14,GPIO.HIGH)
    GPIO.output(15,GPIO.HIGH)
    GPIO.output(18,GPIO.HIGH)
    GPIO.output(23,GPIO.HIGH)


def ApagarSemaforos():
    #Por default pongo las luces apagadas
    GPIO.output(10,GPIO.HIGH)
    GPIO.output(9,GPIO.HIGH)
    GPIO.output(11,GPIO.HIGH)


def ActivarSemaforo1():
    DesactivarControladores()
    GPIO.output(14,GPIO.LOW)

def ActivarSemaforo2():
    DesactivarControladores()
    GPIO.output(15,GPIO.LOW)

def ActivarSemaforo3():
    DesactivarControladores()
    GPIO.output(18,GPIO.HIGH)

def ActivarSemaforo4():
    DesactivarControladores()
    GPIO.output(23,GPIO.HIGH)

def ActivarLuzRoja():
    ApagarSemaforos()
    GPIO.output(10,GPIO.HIGH)

def ActivarLuzAmarilla():
    ApagarSemaforos()
    GPIO.output(9,GPIO.HIGH)

def ActivarLuzVerde():
    ApagarSemaforos()
    GPIO.output(11,GPIO.HIGH)


while True:
    ActivarSemaforo1()
    ActivarLuzRoja()
    time.sleep(1)
    ActivarLuzAmarilla()
    time.sleep(1)
    ActivarLuzVerde()
    time.sleep(1)
'''
    ActivarSemaforo2()
    ActivarLuzRoja()
    time.sleep(0.3)
    ActivarLuzAmarilla()
    time.sleep(0.3)
    ActivarLuzVerde()
    time.sleep(0.3)

    ActivarSemaforo3()
    ActivarLuzRoja()
    time.sleep(0.3)
    ActivarLuzAmarilla()
    time.sleep(0.3)
    ActivarLuzVerde()
    time.sleep(0.3)

    ActivarSemaforo4()
    ActivarLuzRoja()
    time.sleep(0.3)
    ActivarLuzAmarilla()
    time.sleep(0.3)
    ActivarLuzVerde()
    time.sleep(0.3)
'''