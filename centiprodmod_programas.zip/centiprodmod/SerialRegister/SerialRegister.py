#!/usr/bin/env python

import serial
import socket
import datetime

usuarioActual = ""
contrasenaActual = ""
usuarioCapturado = False
sesionIniciada = False
ser = serial.Serial(
   port='/dev/ttyAMA0',
   baudrate=9600,
   parity=serial.PARITY_NONE,
   stopbits=serial.STOPBITS_ONE,
   bytesize=serial.EIGHTBITS,
   timeout=1
   )
TCP_IP = 'localhost'
TCP_PORT = 3501
BUFFER_SIZE = 1024


def RegistrarPeso(idBascula, peso, tiempo):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((TCP_IP, TCP_PORT))
        s.send("peso&" + idBascula + "&" + peso + "&" + tiempo)
        s.close()
        return -1
    except Exception, ex:
        print "Al parecer el servidor central no responde: " + str(ex)


def InicioSesion(usuario, contrasena, tiempo):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((TCP_IP, TCP_PORT))
        s.send("login&" + usuario + "&" + contrasena + "&" + tiempo)
        ValidarLogin(s.recv(BUFFER_SIZE))
        s.close()
        return -1
    except Exception, ex:
        print "Al parecer el servidor central no responde: " + str(ex)


def ValidarLogin(resultadoAcceso):
    #print resultadoAcceso
    global usuarioActual
    usuarioActual = ""
    global contrasenaActual
    contrasenaActual = ""
    global sesionIniciada
    global usuarioCapturado
    if(resultadoAcceso == "aceptado"):
        sesionIniciada = True
    elif(resultadoAcceso == "contrasenaIncorrecta"):
        usuarioCapturado = False
        sesionIniciada = False
        print "Contrasena incorrecta"
    elif(resultadoAcceso == "noExiste"):
        usuarioCapturado = False
        sesionIniciada = False
        print "No existe este usuario"
    else:
        usuarioCapturado = False
        sesionIniciada = False


while True:
    #C = enter
    #F = backspace
    #T = append
    #P = Peso
    try:
        x = ser.readline()
        #print x
        if(x[1:2] == "E"):
            sesionIniciada = False
            usuarioCapturado = False
            contrasenaActual = ""
            usuarioActual = ""
            print "Sesion terminada"
        if(x[:1] == "T"):
            if(sesionIniciada is not True):
                if(x[1:2] == "C"):
                    if(usuarioCapturado is False):
                        usuarioCapturado = True
                    else:
                        #pass
                        InicioSesion(usuarioActual, contrasenaActual, unicode(datetime.datetime.now()))
                elif(x[1:2] == "F"):
                    if(usuarioCapturado is False):
                        usuarioActual = usuarioActual[:-1]
                    else:
                        contrasenaActual = contrasenaActual[:-1]
                elif(x[1:2] == "D"):
                    pass
                elif(x[1:2] == "E"):
                    pass
                elif(x[1:2] == "A"):
                    pass
                elif(x[1:2] == "B"):
                    pass
                elif(x[1:2] == ""):
                    pass
                else:
                    if(usuarioCapturado is False):
                        usuarioActual += x[1:2]
                    else:
                        contrasenaActual += x[1:2]
                print "usuario actual: " + usuarioActual + ", contrasenaActual: " + contrasenaActual
        elif(x[:1] == "P"):
            #print "recibi peso"
            tmpParams = x.split()
            idParams = tmpParams[0].split(":")
            if(sesionIniciada is True):
                print  "Registre el peso de la bascula con id: " + idParams[1] + ", Peso: " + tmpParams[1] + tmpParams[2]
                RegistrarPeso(idParams[1], tmpParams[1] + tmpParams[2], unicode(datetime.datetime.now()))
            else:
                print "No registrado. Peso de la bascula con id: " + idParams[1] + ", Peso: " + tmpParams[1] + tmpParams[2] + " no se ha iniciado la sesion"
        else:
            pass
    except Exception, ex:
        print "Error al leer del puerto serial: " + str(ex)