#!/usr/bin/env python

import smbus
import binascii
import math


bus = smbus.SMBus(1)
address = 0x50

factor1point62 = (1.62 / 60000) * math.pow(2, 23)
factor1point8 = (1.8 / 60000) * math.pow(2, 23)

factorActual = factor1point62
periodo = 2.13e-6
distanciaSensores = 2100


def Escribir(value):
        bus.write_byte_data(address, 0, value)
        return -1


def Leer(comando, cantidad):
   # print "Leyendo: comando " + repr(hex(int("0x" + str(comando), 16))) + ". Cantidad de datos: " + repr(cantidad)
    data = bus.read_i2c_block_data(address, int("0x" + str(comando), 16), cantidad)
    return data


def ObtenerDatosDisponibles():
    return Leer(0, 4)


def ObtenerLecturasDisponibles(sensor, cantidad):
    print "\nSolicitando: sensor: " + repr(sensor) + " cantidad de lecturas: " + repr(cantidad)
    lecturasDisponibles = [0 for y in range(cantidad)]
    for i in range(0, cantidad):
        lecturasDisponibles[i] = Leer(int(str(sensor) + str(i)), 12)
    return lecturasDisponibles


def TraducirLecturasObtenidas(lecturas):
    return {'area': int(binascii.hexlify(bytearray(reversed(lecturas[:4]))), 16),
    'timerRestante': int(binascii.hexlify(bytearray(reversed(lecturas[4:8]))), 16),
    'timerOverflow': int(binascii.hexlify(bytearray(reversed(lecturas[8:12]))), 16)}


def CalcularTiempo(tiempoRestante, timerOverflow):
    return (tiempoRestante * periodo) + ((periodo * math.pow(2, 16)) * timerOverflow)


def CalcularVelocidad(tiempo):
    return distanciaSensores * tiempo


def CalcularPeso(area, velocidad):
    aPrima = area * factorActual
    w = aPrima * (velocidad / 20)
    return w / 9.81


print "Factor: " + repr(factorActual)
print "Periodo: " + repr(periodo)
print "Distancia sensores: " + repr(distanciaSensores)
print "\n"

datosDisponibles = ObtenerDatosDisponibles()

print "Sensores con lecturas disponibles: " + repr(datosDisponibles)


for i in range(0, 4):
    print "\n\n---------------------------------------------------------------"
    lecturasSensorActual = ObtenerLecturasDisponibles(i + 1, datosDisponibles[i])
    print "Sensor " + repr(i + 1) + ":"
    for j in range(0, len(lecturasSensorActual)):
       # print "0x" + repr(i + 1) + repr(j) + ": " + repr(lecturasSensorActual[j])
        lecturasTraducidas = TraducirLecturasObtenidas(lecturasSensorActual[j])
        #print "0x" + repr(i + 1) + repr(j) + ": " + repr(lecturasTraducidas)
        tiempo = CalcularTiempo(lecturasTraducidas['timerRestante'], lecturasTraducidas['timerOverflow'])
        velocidad = CalcularVelocidad(tiempo)
        peso = CalcularPeso(lecturasTraducidas['area'], velocidad)
        print "0x" + repr(i + 1) + repr(j) + ": Velocidad: " + repr(velocidad) + ", Tiempo: " + repr(tiempo) + ", Peso: " + repr(peso)
