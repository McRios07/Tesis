#!/usr/bin/env python

# This script opens CONNECTIONS simultaneous connections to a remote socket,
# and sends a fixed string before closing the connection. The process is then
# repeated indefinitely

# Intended to unit test the tcp_server.py script

import asyncore
import socket
import time

CONNECTIONS = 1
arr = [None] * CONNECTIONS

class Client(asyncore.dispatcher):
    host = "192.168.254.20"
    port = 2101
    mesg = "Hello World\n"

    def __init__(self):
        asyncore.dispatcher.__init__(self)
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
        self.connect((self.host, self.port))

    def handle_connect(self):
        pass

    def handle_close(self):
        self.close()

    def handle_read(self):
        self.recv(4096)

    def writable(self):
        return True

    def handle_write(self):
        self.send(self.mesg)
        self.close()
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
        self.connect((self.host, self.port))

for i in range(len(arr)):
    if not arr[i] or arr[i].closed():
        arr[i] = Client()

asyncore.loop()

# vim: ts=4:sts=4:sw=4:et:ai:incsearch