#!/usr/bin/env python

import smbus
import time
#import socket
import datetime
import RPi.GPIO as GPIO

bus = smbus.SMBus(1)
address = 0x50
TCP_IP = 'localhost'
TCP_PORT = 3501
BUFFER_SIZE = 1024
LINE = 1
tieneError = False

GPIO.setmode(GPIO.BOARD)  # uso la numeracion de la tarjeta'


def IniciarGPIO():
    try:
        GPIO.setwarnings(False)
        GPIO.cleanup()
        GPIO.setup(7, GPIO.IN, pull_up_down=GPIO.PUD_UP)
    except e:
        print "GPIO limpio"


def VerificarInput1():
    input_state = GPIO.input(7)
    if input_state < 1:
        return True


IniciarGPIO()
print "Escuchando por Hard Reset."
try:
    contadorHastaHardReset = 5
    while True:
        estampaTiempo = unicode(datetime.datetime.now())
        try:
            if(VerificarInput1()):
                if (contadorHastaHardReset < 1):
                    print "Hard reset realizado. Reiniciando..."
                    #contadorHastaHardReset = 5
                print "Realizando hard reset en " + repr(contadorHastaHardReset)
                contadorHastaHardReset -= 1
            else:
                contadorHastaHardReset = 5
            time.sleep(1)
        except IOError as e:
            print "Error Entrada/Salida"
except KeyboardInterrupt:
    GPIO.cleanup()
