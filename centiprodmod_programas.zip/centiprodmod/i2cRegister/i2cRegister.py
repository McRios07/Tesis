#!/usr/bin/env python

import smbus
import time
import socket
import datetime
import threading
import struct
import RPi.GPIO as GPIO

bus = smbus.SMBus(1)
address = 0x51
TCP_IP = 'localhost'
TCP_PORT = 3501
BUFFER_SIZE = 1024
LINE = 1
contadorError = 0
tieneError = False

GPIO.setmode(GPIO.BOARD)  # uso la numeracion de la tarjeta'

#Charlyplexing
gpioPins = [36, 38, 40]
estadosPinLed = [
  [1, 0, -1],  # A
  [0, 1, -1],  # B
  [-1, 1, 0],  # C
  [-1, 0, 1],  # D
  [1, -1, 0],  # E
  [0, -1, 1]   # F
]
ordenLeds = [0, 4, 2, 3, 5, 1]


def configurarPin(numPin, estadoPin):
    if estadoPin == -1:
        GPIO.setup(gpioPins[numPin], GPIO.IN)
    else:
        GPIO.setup(gpioPins[numPin], GPIO.OUT)
        GPIO.output(gpioPins[numPin], estadoPin)


def encenderLed(numLed):
    for indicePin, estadoPin in enumerate(estadosPinLed[numLed]):
        configurarPin(indicePin, estadoPin)


def IniciarGPIO():
    try:
        GPIO.setwarnings(False)
        GPIO.cleanup()
    except e:
        print "GPIO limpio"


def ErrorObtenerDatos():
    encenderLed(0)
    time.sleep(0.3)


#def SinErrorObtenerDatos():
#    encenderLed(2)  # enciendo el led


def ActividadI2C():
    encenderLed(1)
    time.sleep(0.5)


def Escribir(value):
    bus.write_byte_data(address, 0, value)
    return -1


def ObtenerDatos():
    #data = bus.read_byte_data(address, 1)
    #return data
    a = []
    a.append(bus.read_byte_data(address, 5))
    a.append(bus.read_byte_data(address, 4))
    a.append(bus.read_byte_data(address, 3))
    a.append(bus.read_byte_data(address, 2))
    return a


def VerificarInput1():
    input_state = GPIO.input(7)
    if input_state < 1:
        print "Boton presionado"


def RegistrarDatos(dato, tiempo):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((TCP_IP, TCP_PORT))
    s.send("db78834IL" + repr(LINE) + "&" + repr(dato) + "&" + repr(tiempo))
    #data = s.recv(BUFFER_SIZE)
    #print data
    s.close()
    return -1


IniciarGPIO()


print "Registro de I2C iniciado y emitiendo."
try:
    #while True:
        time.sleep(1)
        estampaTiempo = unicode(datetime.datetime.now())
        try:
            datoI2C = ObtenerDatos()
            #print datoI2C
            if (len(datoI2C) > 0):
                #RegistrarDatos(datoI2C, estampaTiempo)
                #print repr(datoI2C[0]) + repr(datoI2C[1]) + repr(datoI2C[2]) + repr(datoI2C[3])
                b = struct.pack('4B', *datoI2C)
                print repr(b)
                x = struct.unpack('<f', b)
                print "Equals: " + repr(x)
                #print "[2]:" + repr(datoI2C[0])
                #print "[3]:" + repr(datoI2C[1])
                #print "[4]:" + repr(datoI2C[2])
                #print "[5]:" + repr(datoI2C[3])
            #try:
                #threading.Timer(0, ActividadI2C).start()b = ''.join(chr(i) for i in data)
            #except:
                #pass
        except Exception, e:
            ErrorObtenerDatos()
            contadorError = contadorError + 1
            print "Error Entrada/Salida num " + repr(contadorError) +":"  + str(e)
except KeyboardInterrupt:
    GPIO.cleanup()
    pass  # do cleanup here
    #try:
    #    VerificarInput1()
    #except:
    #    pass
