import sqlite3

class Negocio:

    db = None

    def ConectarBaseDatos(self):
        self.db = sqlite3.connect('/var/www/html/centiprodmod/db/cfg')
        c = self.db.cursor()
        return c

    def DesconectarBaseDatos(self):
        self.db.close()

    def EjecutarConsulta(self, consulta):
        c = self.ConectarBaseDatos()
        c.execute(consulta)
        respuesta = c.fetchall()
        self.DesconectarBaseDatos()
        return respuesta

    def EjecutarEdicion(self, consulta):
        c = self.ConectarBaseDatos()
        respuesta = c.execute(consulta)
        self.db.commit()
        self.DesconectarBaseDatos()
        return respuesta

    def ObtenerIdBascula(self, ip):
        rows = self.EjecutarConsulta("SELECT IdIndicador FROM Indicadores WHERE Ip = '" + str(ip) + "'")
        return str(rows[0][0])

    def ObtenerIpBascula(self, id):
        rows = self.EjecutarConsulta("SELECT Ip FROM Indicadores WHERE IdIndicador = " + str(id))
        return str(rows[0][0])

    def ObtenerPuertoBascula(self, id):
        rows = self.EjecutarConsulta("SELECT Puerto FROM Indicadores WHERE IdIndicador = " + str(id))
        return str(rows[0][0])

    def RegistrarPesaje(self, ipBascula, fechaHora, detalle):
        consulta = "INSERT INTO RegistroPesaje(IpBascula, FechaHora, Detalle) "
        consulta = consulta + "VALUES('" + str(ipBascula) + "', '" + str(fechaHora) + "', '" + detalle + "')"
        return self.EjecutarEdicion(consulta)

    def ObtenerSetPoints(self, num):
        rows = self.EjecutarConsulta("SELECT Setpoints FROM Indicadores WHERE IdIndicador = " + str(num))
        return str(rows[0][0])

    def ObtenerIdGrupoBascula(self, num):
        rows = self.EjecutarConsulta("SELECT Grupo FROM Indicadores WHERE IdIndicador = " + str(num))
        return str(rows[0][0])

    def ObtenerNumBascula(self, id):
        rows = self.EjecutarConsulta("SELECT NumBascula FROM Indicadores WHERE IdIndicador = " + str(id))
        return str(rows[0][0])


''' Testing '''

'''

negocio = Negocio()

print(negocio.ObternerIdBascula("192.168.254.110"))
print(negocio.ObternerIpBascula(1))

'''