import RPi.GPIO as GPIO
import time
import serial
import re

GPIO.cleanup()
GPIO.setmode(GPIO.BCM)
GPIO.setup(27, GPIO.OUT)
GPIO.setup(22, GPIO.OUT)
GPIO.setup(5, GPIO.OUT)


GPIO.output(27,GPIO.LOW)
GPIO.output(22,GPIO.LOW)
GPIO.output(5,GPIO.LOW)


spLow = 0.3
spUnder = 0.4
spOver = 0.6
spHigh = 0.7


ser = serial.Serial(
       port='/dev/ttyUSB0',
       baudrate = 9600,
       parity=serial.PARITY_NONE,
       stopbits=serial.STOPBITS_ONE,
       bytesize=serial.EIGHTBITS,
       timeout=1
   )

def getNumbers(strg):
    array = re.findall(r'[0-9\-.]+', strg)
    return array

def MostrarNivelEnTorreta(peso):
    global spLow, spUnder, spOver, spHigh
    print(peso)
    if(peso <= spUnder):
        GPIO.output(27,GPIO.HIGH)
        GPIO.output(22,GPIO.LOW)
        GPIO.output(5,GPIO.LOW)
        print("soy Low")
    elif(peso > spUnder and peso < spOver):
        GPIO.output(27,GPIO.LOW)
        GPIO.output(22,GPIO.HIGH)
        GPIO.output(5,GPIO.LOW)
        print("soy Target")
    elif(peso >= spOver):
        GPIO.output(27,GPIO.LOW)
        GPIO.output(22,GPIO.LOW)
        GPIO.output(5,GPIO.HIGH)
        print("soy Over")


def handle_serial():
    global ser, pesoActual, estoyPreparado
    while True:
        try:
            byt = ser.readline()
            pesoActual = getNumbers(str(byt))[0]
            MostrarNivelEnTorreta(float(pesoActual))
            #print(pesoActual)
        except:
            #-- Cuando el indicador no entrega una cadena legible
            pass


while True:
    handle_serial()
    time.sleep(0.5)
    print("slipie")
'''
'''
