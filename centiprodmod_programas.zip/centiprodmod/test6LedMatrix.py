

import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BOARD)

#Charlyplexing
pins = [36, 38, 40]
#pins = [16, 20, 21]

pin_led_states = [
  [1, 0, -1],  # A
  [0, 1, -1],  # B
  [-1, 1, 0],  # C
  [-1, 0, 1],  # D
  [1, -1, 0],  # E
  [0, -1, 1]   # F
]


ordenLeds = [0, 4, 2, 3, 5, 1]


def set_pin(pin_index, pin_state):
    if pin_state == -1:
        GPIO.setup(pins[pin_index], GPIO.IN)
    else:
        GPIO.setup(pins[pin_index], GPIO.OUT)
        GPIO.output(pins[pin_index], pin_state)


def light_led(led_number):
    for pin_index, pin_state in enumerate(pin_led_states[led_number]):
        set_pin(pin_index, pin_state)


set_pin(0, -1)
set_pin(1, -1)
set_pin(2, -1)


while True:
    for led in ordenLeds:
        light_led(led)
        time.sleep(0.1)
    for led in reversed(ordenLeds):
        light_led(led)
        time.sleep(0.1)

    """
    light_led(0)
    time.sleep(0.05)
    light_led(4)
    time.sleep(0.05)
    light_led(2)
    time.sleep(0.05)
    light_led(3)
    time.sleep(0.05)
    light_led(5)
    time.sleep(0.05)
    light_led(1)
    time.sleep(0.05)
    """



