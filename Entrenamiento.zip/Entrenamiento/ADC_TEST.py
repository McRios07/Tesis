import spidev
import RPi.GPIO as GPIO
import time
import datetime

GPIO.setmode(GPIO.BCM)
#GPIO.setup(2,GPIO.IN, pull_up_down=GPIO.PUD_DOWN)  # Pin Ready

spi = spidev.SpiDev()
spi.open(0, 0)
spi.max_speed_hz = 976000
spi.mode = 0b00

'''
c = 0
valores = []
tiempos = []

inicio = False
print(len(valores))
while True:

    if GPIO.input(2):
        adc = spi.xfer2([0xD0,0x00,0x00])
        start = datetime.datetime.now()
        tiempos.append(start)
        doc= (adc[0] << 9 | adc[1] << 1 | adc[2] >> 7) & 0xFFF
        v = (doc * 3.3)/4096
        valores.append(v)
        inicio = True
    else:
        if inicio == True:
            #print("Voltaje = %s"%valores)
            print(len(valores))
            print(len(tiempos))
            inicio = False
            for i in range(10):
                print(tiempos[i])

print("Voltaje = %s"%valores)
print(len(valores))
'''

try:
    while True:
        adc = spi.xfer2([0xD0,0x00,0x00])
        doc= (adc[0] << 9 | adc[1] << 1 | adc[2] >> 7) & 0xFFF
        v = (doc * 3.3)/4096
        print("Voltaje = %s"%v)
        #print("Fecha y hora = %s\n"%datetime.datetime.now())
        time.sleep(0.001)

except KeyboardInterrupt:
    spi.close()

