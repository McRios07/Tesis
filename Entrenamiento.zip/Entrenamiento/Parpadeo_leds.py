import RPi.GPIO as GPIO
from time import sleep
import sys

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM) # set the board numbering system to BCM

# setup our output pins
GPIO.setup(19,GPIO.OUT)
GPIO.setup(20,GPIO.OUT)

def TurnLedsOn():
    print "Lights on"
    GPIO.output(19,GPIO.HIGH)
    GPIO.output(20,GPIO.HIGH)
    sleep(1) # sleep for 1 second

def TurnLedsOff():
    print "Lights off"
    GPIO.output(19,GPIO.LOW)
    GPIO.output(20,GPIO.LOW)
    sleep(1) # sleep for 1 second

#-- Ciclo principal del programa
try:
    while True:
        TurnLedsOn()
        TurnLedsOff()
except:
    print("Unexpected error:", sys.exc_info()[1])
    GPIO.cleanup()