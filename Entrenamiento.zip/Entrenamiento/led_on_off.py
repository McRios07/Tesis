import RPi.GPIO as GPIO
import time
GPIO.setmode(GPIO.BCM)
GPIO.setup(19, GPIO.OUT)
GPIO.setup(26, GPIO.OUT)

print "Lights on"
GPIO.output(19,GPIO.HIGH)
GPIO.output(26,GPIO.HIGH)
time.sleep(5)
print "Lights off"
GPIO.output(19,GPIO.LOW)
GPIO.output(26,GPIO.LOW)