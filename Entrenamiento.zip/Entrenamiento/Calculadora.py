# coding=utf-8

import sys
import math
import sqlite3

'''
class Calculadora:

    def __init__(self):
        pass

    def Suma(self,a,b):
        return a + b

    def Resta(self,a,b):
        return a - b

    def Division(self,a,b):
        if b == 0 :
            return 0
        return a / b

    def Multiplicacion(self,a,b):
        return a * b

    def Factorial(self,a):
        resultado = 1
        for i in range(1,a + 1):
            resultado = resultado * i
        return resultado


x = Calculadora()

a = float(raw_input('Introduce el primer valor: '))
b = float(raw_input('Introduce el segundo valor: '))
print ("\nSuma = " + str(x.Suma(a,b)))
print ("Resta = " + str(x.Resta(a,b)))
print ("Multiplicacion = " + str(x.Multiplicacion(a,b)))
print ("Division = " + str(x.Division(a,b)))
print ("Factorial del primer valor = " + str(x.Factorial(int(a))))


p1 = Persona("Huachi",23.0,"Negro")
p2 = Persona("Mau",26.0,"Negro")
p3 = Persona("Fabian",39.0,"Guero")

personas = [p1,p2,p3]

x = Poblacion(personas)

name_mayor, mayor = x.ObtenerEdadMayor()
name_menor, menor = x.ObtenerEdadMenor()

print ("El promedio de edad entre %s, %s y %s es %s años " %(p1.Nombre, p2.Nombre, p3.Nombre,x.ObtenerEdadPromedio()))
print ("Cantidad de negros = " + str(x.ObtenerCantidadNegros()))
print ("%s es el mayor con %s años" %(name_mayor, mayor))
print ("%s es el menor con %s años" %(name_menor, menor))



class Persona:
    Nombre = ""
    Edad = 0
    Color = ""

    def __init__(self,nombre,edad,color):
        self.Nombre = nombre
        self.Edad = edad
        self.Color = color

class Poblacion:
    Personas = []

    def __init__(self,gente):
        self.Personas = gente

    def ObtenerEdadPromedio(self):
        suma = 0
        for i in self.Personas:
            suma += i.Edad
        return suma / len(self.Personas)


    def ObtenerCantidadNegros(self):
        suma = 0
        for i in self.Personas:
            if i.Color =="Negro":
                suma += 1
        return suma

    def ObtenerEdadMayor(self):
        mayor = 0
        for i in self.Personas:
            if i.Edad > mayor:
                mayor = i.Edad
                nombre = i.Nombre
        return nombre, mayor

    def ObtenerEdadMenor(self):
        menor = 10000
        for i in self.Personas:
            if i.Edad < menor:
                menor = i.Edad
                nombre = i.Nombre
        return nombre, menor

class Menu:
    personas = []

    def __init__(self):
        pass

    def mostrarMenu(self):
        print ("1. Agregar")
        print ("2. Eliminar")
        print ("3. Mostrar lista")

    def agregar(self,nombre,edad,color):
        persona = Persona(nombre,edad,color)
        self.personas.append(persona)

    def buscar(self,nombre):
        respuesta = -1
        contador = -1
        for i in self.personas:
            contador+= 1
            if i.Nombre == nombre:
                respuesta = contador
        return respuesta

    def eliminar(self,index):
        del(self.personas[index])

    def mostrarLista(self):
        for i in self.personas:
            print("%s %s años %s" %(i.Nombre, i.Edad, i.Color))

menu= Menu()
while True:
    menu.mostrarMenu()
    opcion = int((raw_input('Introduce una opcion: ')))
    if opcion == 1:
        nombre = (raw_input('Introduce el nombre: '))
        edad = float(raw_input('Introduce la edad: '))
        color = (raw_input('Introduce el color: '))
        menu.agregar(nombre,edad,color)
    elif opcion == 2:
        nombre = (raw_input('Introduce el nombre a eliminar: '))
        if menu.buscar(nombre) > -1:
            menu.eliminar(menu.buscar(nombre))
            print("Nombre eliminado")
        else:
            print("No se encontró el nombre a eliminar")
    elif opcion == 3:
        menu.mostrarLista()
    else:
        print("Selecciona otra opcion")






def EstoyCalibrando():
    c = ConectarBaseDatos()
    c.execute("SELECT Valor FROM Configuracion WHERE Configuracion = 'EstaCalibrando'")
    estoyCalibrando = c.fetchone()
    print("estoyCalibrando: " + str(estoyCalibrando[0]))
    return estoyCalibrando[0]

def bla():
    c = ConectarBaseDatos()
    consulta = ("INSERT INTO MuestrasCalibracion(idVehiculo,  Fecha, EjeRegistrado, NumeroSensor, PesoRegistrado, PesoRuedaVehiculo, " +
        "Total, Ejes, Velocidad, Largo) VALUES (" + str(idVehiculoCalibrando) + ", '" + str(fechaHora) + "', " +
    c.execute(consulta)
        db.commit()
    DesconectarBaseDatos()
    '''

class Crud():
    db = None

    def __init__(self):
        pass

    def ConectarBaseDatos(self):
        self.db = sqlite3.connect('/home/pi/Entrenamiento/db_personas')
        c = self.db.cursor()
        return c

    def DesconectarBaseDatos(self):
        self.db.close()

    def Select(self,consulta):
        cursor = self.ConectarBaseDatos()
        cursor.execute(consulta)
        rows = cursor.fetchall()
        self.DesconectarBaseDatos()
        return rows

    def Insert(self,consulta):
        cursor = self.ConectarBaseDatos()
        respuesta = cursor.execute(consulta)
        self.db.commit()
        self.DesconectarBaseDatos()
        return respuesta

    def Update(self,consulta):
        cursor = self.ConectarBaseDatos()
        respuesta = cursor.execute(consulta)
        self.db.commit()
        self.DesconectarBaseDatos()
        return respuesta

    def Delete(self,consulta):
        cursor = self.ConectarBaseDatos()
        respuesta = cursor.execute(consulta)
        self.db.commit()
        self.DesconectarBaseDatos()
        return respuesta

class Negocio():
    c =Crud()
    def __init__(self):
        pass

    def agregarPersona(self,nombre,edad,color):
        consulta = ("INSERT INTO Personas(Usuario,Edad,Color) VALUES('%s',%s,'%s')"%(nombre,edad,color))
        return self.c.Insert(consulta)

    def obtenerNombres(self):
        consulta = ("SELECT Usuario FROM Personas")
        return self.c.Select(consulta)

    def eliminarPersonaID(self,idPersona):
        consulta = ("DELETE FROM Personas WHERE IdPersona = %s" %(idPersona))
        self.c.Delete(consulta)

    def obtenerIdPersona(self,nombre):
        consulta = ("SELECT IdPersona,Usuario FROM Personas WHERE Usuario Like '%%%s%%'"%(nombre))
        return self.c.Select(consulta)

    def obtenerLista(self):
        consulta = ("SELECT * FROM Personas")
        return self.c.Select(consulta)

    def obtenerEdades(self):
        consulta = ("SELECT Edad FROM Personas")
        return self.c.Select(consulta)

    def obtenerNombresEdades(self):
        consulta = ("SELECT Usuario,Edad FROM Personas")
        return self.c.Select(consulta)

    def obtenerColores(self):
        consulta = ("SELECT Color FROM Personas")
        return self.c.Select(consulta)

    def actualizarPersona(self,idPersona,nombre,edad,color):
        consulta = ("UPDATE Personas SET Usuario = '%s', Edad = %s, Color = '%s' WHERE IdPersona = %s"%(nombre,edad,color,idPersona))
        return self.c.Update(consulta)

def mostrarMenu():
    print ("\n1. Agregar")
    print ("2. Eliminar por ID")
    print ("3. Mostrar lista")
    print ("4. Buscar ID por nombre")
    print ("5. Mostrar edad promedio")
    print ("6. Mostrar edad mayor")
    print ("7. Mostrar edad menor")
    print ("8. Mostrar cantidad de negros")
    print ("9. Actualizar usuario\n")

class Backend():
    n = Negocio()
    def __init__(self):
        pass

    def agregar(self,nombre,edad,color):
        return self.n.agregarPersona(nombre,edad,color)

    def eliminar(self,idPersona):
        self.n.eliminarPersonaID(idPersona)
        print(('\nID %s eliminado\n' %idPersona))

    def mostrarLista(self):
        lista = self.n.obtenerLista()
        for i in lista:
            print(i)

    def buscarId(self,nombre):
        lista = self.n.obtenerIdPersona(nombre)
        return lista

    def mostrarEdadPromedio(self):
        lista = self.n.obtenerEdades()
        suma =0.0
        for i in lista:
            suma+= int(i[0])
        print ('\nLa edad promedio es %s años' %(suma/len(lista)))

    def mostrarEdadMayor(self):
        lista = self.n.obtenerNombresEdades()
        mayor =0
        for i in lista:
            if int(i[1]) > mayor:
                mayor = int(i[1])
                nombre = i[0]
        print ("El mayor es %s con %s anios" %(nombre,mayor))

    def mostrarEdadMenor(self):
        lista = self.n.obtenerNombresEdades()
        menor =1000
        for i in lista:
            if int(i[1]) < menor:
                menor = int(i[1])
                nombre = i[0]
        print ("\nEl menor es %s con %s anios" %(nombre,menor))

    def mostrarCantidadNegros(self):
        lista = self.n.obtenerColores()
        suma = 0
        for i in lista:
            if i[0] == 'negro':
                suma+= 1
        print ('Hay %s negros en la base de datos' %suma)

    def actualizar(self,idPersona,nombre,edad,color):
        return self.n.actualizarPersona(idPersona,nombre,edad,color)

b = Backend()

while (True):
    mostrarMenu()
    opcion = int((raw_input('Introduce una opcion: ')))
    if opcion == 1:
        nombre = (raw_input('Introduce el nombre: '))
        edad = float(raw_input('Introduce la edad: '))
        color = (raw_input('Introduce el color: '))
        b.agregar(nombre,edad,color)
    elif opcion == 2:
        nombre = (raw_input('Introduce el ID a eliminar: '))
        b.eliminar(nombre)
    elif opcion == 3:
        b.mostrarLista()
    elif opcion == 4:
        nombre = (raw_input('Introduce el nombre a buscar: '))
        ids = b.buscarId(nombre)
        if len(ids) > 0:
            for i in ids:
                print(i)
        else:
            print("Nombre no encontrado")
    elif opcion == 5:
        b.mostrarEdadPromedio()
    elif opcion == 6:
        b.mostrarEdadMayor()
    elif opcion == 7:
        b.mostrarEdadMenor()
    elif opcion == 8:
        b.mostrarCantidadNegros()
    elif opcion == 9:
        nombre = (raw_input('Introduce el nombre a actualizar: '))
        ids = b.buscarId(nombre)
        if len(ids) == 1:
            edad = float(raw_input('Introduce la edad: '))
            color = (raw_input('Introduce el color: '))
            b.actualizar(ids[0][0],nombre,edad,color)
            print("Usuario actualizado")
        else:
            print("Nombre no encontrado")