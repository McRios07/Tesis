# Tesis
Repositorio de los archivos de matlab y python de la maestría 
