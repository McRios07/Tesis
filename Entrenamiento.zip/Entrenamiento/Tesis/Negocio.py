import Crud

class negocio():
	c =Crud.crud()
	def __init__(self):
		pass

	def getPlants(self):
		consult = ("SELECT idPlanta, Nombre, Sensor, Descripcion, Presion, Habilitado, Calibrando, Calibrado FROM plantas")
		return self.c.select(consult)

	def newPlant(self,Nombre,Sensor,Presion,Habilitado,Descripcion,Calibrando,Calibrado):
		consult = ("INSERT INTO plantas(Nombre,Sensor,Presion,Habilitado,Descripcion,Calibrando,Calibrado) VALUES('%s','%s','%s','%s','%s','%s','%s')"%(Nombre,Sensor,Presion,Habilitado,Descripcion,Calibrando,Calibrado))
		return self.c.insert(consult)

	def modifyPlant(self,idPlanta,nombre, sensor, descripcion):
		consult = ("UPDATE plantas SET Nombre = '%s', Sensor = '%s', Descripcion = '%s' WHERE IdPlanta = '%s'"%(nombre,sensor,descripcion,idPlanta))    
		return self.c.update(consult)

	def deletePlant(self,idPlanta):
		consult = ("DELETE FROM plantas WHERE IdPlanta = '%s'"%(idPlanta))
		return self.c.delete(consult)

	def setCalibrado(self,value,idPlant):
		consult = ("UPDATE plantas SET Calibrado = '%s' WHERE IdPlanta = '%s'"%(value,idPlant))
		return self.c.update(consult)

	def getPressureCalibrando(self,idPlanta):
		consult = ("SELECT Presion FROM plantas WHERE IdPlanta = '%s'"%(idPlanta))
		return self.c.select(consult)

	def setPressureCalibrando(self,value,idPlant):
		consult = ("UPDATE plantas SET Presion = '%s' WHERE IdPlanta = '%s'"%(value,idPlant))
		return self.c.update(consult)    

	def getCalibratedPlants(self):
		consult = ("SELECT IdPlanta,Sensor,Nombre FROM plantas WHERE Calibrado = 1")
		return self.c.select(consult)

	def getCalibrando(self,idPlanta):
		consult = ("SELECT Calibrando FROM plantas WHERE IdPlanta = '%s'"%(idPlanta))
		return self.c.select(consult)

	def setCalibrando(self,value,idPlant):
		consult = ("UPDATE plantas SET Calibrando = '%s' WHERE IdPlanta = '%s'"%(value,idPlant))
		return self.c.update(consult) 

	def newRecord(self,idPlant,date,pressure,temperature):
		consult = ("INSERT INTO registroplantas(IdPlanta,FechaHora,Presion,Temperatura) VALUES('%s','%s','%s','%s')"%(idPlant,date,pressure,temperature))
		return self.c.insert(consult)

	def getSetting(self,settings):
		consult = ("SELECT Valor FROM configuracion WHERE Configuracion = '%s'"%(settings))
		return self.c.select(consult)[0][0]

	def setSetting(self,setting,value):
		consult = ("UPDATE configuracion SET Valor = '%s' WHERE Configuracion = '%s'"%(value,setting))
		return self.c.update(consult)
		
		
