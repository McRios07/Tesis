import socket
import threading
import Negocio
import os
import json
import time

# TCP Configuration
HOST = '' # escucho en todas las interfaces de red
PORT = 30000
s = None
conn = None
addr = None
negocio = None


def callCalibracion():
	os.system("python2 Calibracion.py")
	
def callRecepcion():
	os.system("python2 Recepcion.py")
	
	
def InicializarServidor():
	# esperar por una nueva conexion.
	global s,HOST,PORT
	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
	s.bind((HOST, PORT))
	s.listen(1)
	print("Servidor Inicializado")

def EsperarConexion():
	# aceptar nueva conexion
	global conn,addr
	print("Esperando una conexion")
	conn, addr = s.accept()
	print ('Conexion aceptada', addr)
	
def readTCP():
	return conn.recv(1024)

def writeTCP(massage):
	conn.send(massage)
	time.sleep(0.05)
	
def Desconectar():
	conn.close()
	
def ProcesarMensaje(msg):
	if msg[0] == 'getPlants':
		data = negocio.getPlants()
		return json.dumps(data)
		
	elif msg[0] == 'newPlant':
		data = negocio.newPlant(msg[1],msg[2],msg[3],msg[4],msg[5],msg[6],msg[7])
		return 'ACK!'
		
	elif msg[0] == 'modifyPlant':
		data = negocio.modifyPlant(msg[1],msg[2],msg[3],msg[4])
		return 'ACK!'
		
	elif msg[0] == 'deletePlant':
		data = negocio.deletePlant(msg[1])
		return 'ACK!'
		
	elif msg[0] == 'setCalibrando':
		data = negocio.setCalibrando(msg[1],msg[2])
		return 'ACK!'
		
	elif msg[0] == 'setCalibrado':
		data = negocio.setCalibrado(msg[1],msg[2])
		return 'ACK!'
		
	elif msg[0] == 'setSetting':
		data = negocio.setSetting(msg[1],msg[2])
		return 'ACK!'
		
	elif msg[0] == 'getSetting':
		data = negocio.getSetting(msg[1])
		return json.dumps(data)
		
	elif msg[0] == 'getCalibratedPlants':
		data = negocio.getCalibratedPlants()
		return json.dumps(data)
		
	elif msg[0] == 'startCalibration':
		data = negocio.setCalibrando('1',msg[1])
		calibracion.start()
		return 'ACK!'
		
	elif msg[0] == 'stopCalibration':
		data = negocio.modifyPlant(msg[1],msg[2],msg[3])
		calibracion.join()
		return 'ACK!'
		
	elif msg[0] == 'getCalibrado':
		data = negocio.getCalibrado(msg[1])
		return json.dumps(data)
		
	elif msg[0] == 'getPressureCalibrando':
		data = negocio.getPressureCalibrando(msg[1])
		return json.dumps(data)


calibracion = threading.Thread(target=callCalibracion)
recepcion = threading.Thread(target=callRecepcion)

negocio = Negocio.negocio()
InicializarServidor()

while True:
	try:
		EsperarConexion()
		data = readTCP()
		print 'Received {}'.format(data)
		msg = data.split('#')
		data = ProcesarMensaje(msg)
		writeTCP(data + '\n')
	except:
		Desconectar()
        
        
        
        
#print 'Received {}'.format(server.handle_client_read())
#server.handle_client_write('ACK!\n')
