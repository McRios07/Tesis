import Planta
import Negocio
import RPi.GPIO as GPIO

GPIO.setwarnings(False)

negocio = Negocio.negocio()
columns = negocio.getCalibratedPlants()

#Seleccionar pin del sensor
if columns[0][1] == 1:
    pin = negocio.getSetting("Sensor1")
else:
    pin = negocio.getSetting("Sensor2")
port = 0
id = columns[0][0]

sensor = Planta.plant(int(pin),port,id)

pinRef = negocio.getSetting("SensorReferencia")
portRef = 1
idRef = 0

sensorRef = Planta.plant(int(pinRef),portRef,idRef)

def pressures()
	atmosphericPressure = sensorRef.getPressure()

	initialPressure = float(negocio.getSetting("presionInicial"))
	margenRef = float(negocio.getSetting("Margen"))

	pressureInf =initialPressure - (margenRef/100.0)*initialPressure
	pressureSup =initialPressure + (margenRef/100.0)*initialPressure
	return atmosphericPressure, pressureInf, pressureSup


while (negocio.getCalibrando(id)[0][0] == 1):
	atmosphericPressure, pressureInf, pressureSup = pressures()
    pressure =sensor.getPressure()
    negocio.setPressureCalibrando(pressure,id)
    if ((pressure - atmosphericPressure) > pressureInf and (pressure - atmosphericPressure) < pressureSup):
        negocio.setCalibrado('1',id)
