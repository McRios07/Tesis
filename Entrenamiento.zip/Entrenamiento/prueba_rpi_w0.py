import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)
GPIO.setup(2, GPIO.OUT)  # Pin Ready
GPIO.setup(3, GPIO.OUT)  # Pin Ready
GPIO.setup(4, GPIO.OUT)  # Pin Ready

class semaforo():

    def __init__(self):
        GPIO.setwarnings(False)
        self.ledsOFF()

    def greenON(self):
        GPIO.output(2,GPIO.HIGH)
        GPIO.output(3,GPIO.LOW)
        GPIO.output(4,GPIO.LOW)

    def yellowON(self):
        GPIO.output(2,GPIO.LOW)
        GPIO.output(3,GPIO.HIGH)
        GPIO.output(4,GPIO.LOW)

    def redON(self):
        GPIO.output(2,GPIO.LOW)
        GPIO.output(3,GPIO.LOW)
        GPIO.output(4,GPIO.HIGH)

    def ledsOFF(self):
        GPIO.output(2,GPIO.LOW)
        GPIO.output(3,GPIO.LOW)
        GPIO.output(4,GPIO.LOW)

s1 = semaforo()
while (True):
    s1.greenON()
    time.sleep(1)
    s1.yellowON()
    time.sleep(1)
    s1.redON()
    time.sleep(1)
    s1.ledsOFF()